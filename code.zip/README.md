# Incident Workflow Backend

Event-driven workflow framework for incident management built on AWS.

## Architecture

- **API Gateway**: RESTful API endpoints
- **Lambda Functions**: Serverless compute for business logic
- **DynamoDB**: NoSQL database for incident data
- **EventBridge**: Event bus for domain events
- **Node.js 20+**: Runtime environment
- **TypeScript**: Type-safe development

## Prerequisites

- Node.js 24+
- AWS CLI configured
- Terraform 1.5+
- AWS Account with appropriate permissions

## Installation

# Prerequisites verification

! Important note: Ensure wsl is setup and working fine. Contact Buhner, Jayce (DBHDS) upon request submission in powerApps

Copy and run the following to setup NodeJS in wsl

```shell
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs
```

go through the env files for quick reference

# Install dependencies

npm install

### Build the project

```shell
npm run build
```

### Package the built files

```shell
- npm run package
```

### Publishing to s3 (ensure aws creds are setup before publish)

```shell
- npm run publish
```

### Resolve issue with archiver dependency (optional)

```shell
npm i -D archiver
```

### Resolve client-s3 (optional)

```shell
- npm i @aws-sdk/client-s3
```

### Clean the output (optional)

```shell
- npm run clean
```
