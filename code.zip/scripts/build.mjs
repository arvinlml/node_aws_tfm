import { build } from "esbuild";
import { mkdir, readdir } from "node:fs/promises";
import path from "node:path";

const handlersDir = "src/handlers";
const entries = await readdir(handlersDir, { withFileTypes: true });

const handlers = entries.filter((e) => e.isFile() && e.name.endsWith(".ts")).map((e) => path.join(handlersDir, e.name));

if (handlers.length === 0) {
  throw new Error("No handlers found in src/handlers/*.ts");
}

await mkdir("dist/handlers", { recursive: true });

await Promise.all(
  handlers.map(async (entry) => {
    const base = path.basename(entry, ".ts");
    const outdir = `dist/handlers/${base}`;
    await mkdir(outdir, { recursive: true });

    await build({
      entryPoints: [entry],
      outfile: `${outdir}/index.js`,
      platform: "node",
      target: "node24",
      format: "cjs",
      bundle: true,
      sourcemap: true,
      minify: true,
      external: ["@aws-sdk/*", "uuid", "pg"],
    });
  })
);

console.log(`Built ${handlers.length} handler bundle(s) into dist/handlers/*`);
