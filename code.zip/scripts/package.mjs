import { createWriteStream } from "node:fs";
import { mkdir, stat } from "node:fs/promises";
import path from "node:path";
import archiver from "archiver";

import crypto from "node:crypto";
import { createReadStream } from "node:fs";

import { readdir } from "node:fs/promises";
function zipDir({ srcDir, outZip }) {
  return new Promise((resolve, reject) => {
    const output = createWriteStream(outZip);
    const archive = archiver("zip", { zlib: { level: 9 } });

    output.on("close", resolve);
    archive.on("error", reject);

    archive.pipe(output);
    archive.directory(srcDir, false);
    archive.finalize();
  });
}

async function sha256File(filePath) {
  await stat(filePath);
  const hash = crypto.createHash("sha256");
  await new Promise((resolve, reject) => {
    const s = createReadStream(filePath);
    s.on("data", (d) => hash.update(d));
    s.on("end", resolve);
    s.on("error", reject);
  });
  return hash.digest("hex");
}

await mkdir("dist/zips", { recursive: true });

/**
 * 1) Package handler zips
 */
const entries = await readdir("dist/handlers", { withFileTypes: true });
const handlerDirs = entries.filter((e) => e.isDirectory()).map((e) => `dist/handlers/${e.name}`);
const handlers = [];

for (const dir of handlerDirs) {
  const name = path.basename(dir);
  const zipPath = `dist/zips/${name}.zip`;
  await zipDir({ srcDir: dir, outZip: zipPath });
  const sha256 = await sha256File(zipPath);
  handlers.push({ name, zipPath, sha256 });
}

/**
 * 2) Build Layer zip
 * Lambda layer structure must be: nodejs/node_modules/<deps>
 * We’ll copy production deps into dist/layer/nodejs/node_modules via npm.
 */
await mkdir("dist/layer/nodejs", { recursive: true });

// Create a minimal package.json for the layer install
const layerPkgJsonPath = "dist/layer/nodejs/package.json";
const service = process.env.SERVICE_NAME ?? "dbhds-workflow-service";
const layerPkg = {
  name: `${service}-layer`,
  private: true,
  type: "commonjs",
  dependencies: {
    "@aws-sdk/client-dynamodb": "^3.758.0",
    "@aws-sdk/lib-dynamodb": "^3.758.0",
    uuid: "^9.0.1",
  },
};

await BunWriteJson(layerPkgJsonPath, layerPkg);

// Install prod deps into dist/layer/nodejs/node_modules
// Uses the system `npm`. In CI, ensure npm is available.
await run("npm", ["install", "--omit=dev", "--no-audit", "--no-fund"], { cwd: "dist/layer/nodejs" });

const layerZipPath = `dist/zips/${service}-layer.zip`;
await zipDir({ srcDir: "dist/layer", outZip: layerZipPath });
const layerSha256 = await sha256File(layerZipPath);

/**
 * 3) Manifest for Terraform
 */
const manifest = {
  generatedAt: new Date().toISOString(),
  handlers,
  layer: { name: `${service}-layer`, zipPath: layerZipPath, sha256: layerSha256 },
};

await BunWriteJson("dist/manifest.json", manifest);

console.log(`Packaged ${handlers.length} handler zip(s) + layer zip into dist/zips/`);
console.log(`Wrote dist/manifest.json`);

async function run(cmd, args, opts = {}) {
  const { spawn } = await import("node:child_process");
  await new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: "inherit", ...opts });
    p.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(`${cmd} exited ${code}`))));
    p.on("error", reject);
  });
}

async function BunWriteJson(filePath, obj) {
  const { writeFile } = await import("node:fs/promises");
  await writeFile(filePath, JSON.stringify(obj, null, 2));
}
