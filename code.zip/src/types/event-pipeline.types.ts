// Type definitions
export interface ProcessingResults {
  successful: number;
  failed: number;
  errors: Array<{
    recordId: string | undefined;
    error: string;
  }>;
}

export interface EventMapping {
  eventType: string;
  eventVersion?: string;
  source: string;
  detailType: string;
  includeFields?: string[];
}

export interface Transformation {
  field: string;
  type: "enum" | "uppercase" | "lowercase" | "mask" | "format";
  values?: string[];
  defaultValue?: string;
  maskPattern?: string;
  formatter?: string;
}

export interface TableMetadata {
  tableName: string;
  eventMappings?: {
    INSERT?: EventMapping | undefined;
    MODIFY?: EventMapping | undefined;
    REMOVE?: EventMapping | undefined;
  };
  transformations?: Transformation[];
}

export interface DomainEventDetail {
  eventType: string;
  eventVersion: string;
  operation: string;
  timestamp: string;
  tableName: string;
  data?: Record<string, any>;
  changes?: Record<string, { from: any; to: any }>;
  deletedData?: Record<string, any>;
  correlationId?: string;
  validationWarnings?: Array<{
    field: string;
    message: string;
    validValues: string[];
  }>;
}
