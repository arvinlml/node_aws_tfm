import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
import { randomUUID } from "crypto";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { IncidentStatus, IncidentSeverity, Gender, Incident } from "../types/incident.types";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGINS || "*",
  "Access-Control-Allow-Headers":
    "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Correlation-ID",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
  "Access-Control-Allow-Credentials": "true",
  "Content-Type": "application/json",
};

/**
 * Generate next sequential incident ID using DynamoDB atomic counter
 */
async function generateIncidentId(): Promise<string> {
  const counterTableName = process.env.INCIDENTS_TABLE!;
  const counterKey = "COUNTER#INCIDENT";

  try {
    const result = await docClient.send(
      new UpdateCommand({
        TableName: counterTableName,
        Key: {
          incidentId: counterKey,
        },
        UpdateExpression: "SET #counter = if_not_exists(#counter, :start) + :increment",
        ExpressionAttributeNames: {
          "#counter": "counter",
        },
        ExpressionAttributeValues: {
          ":start": 100000,
          ":increment": 1,
        },
        ReturnValues: "UPDATED_NEW",
      }),
    );

    const nextId = result.Attributes?.counter || 100001;
    return `INC-${nextId}`;
  } catch (error) {
    console.error("Error generating incident ID:", error);
    return `INC-${Date.now().toString().slice(-6)}`;
  }
}

export const handler = async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
  console.log("SaveIncident handler invoked", {
    requestId: context.awsRequestId,
    path: event.path,
    method: event.httpMethod,
  });

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: "",
    };
  }

  const correlationId = event.headers["X-Correlation-ID"] || event.headers["x-correlation-id"] || randomUUID();

  try {
    if (event.httpMethod !== "POST") {
      return buildErrorResponse(405, "Method Not Allowed", correlationId);
    }

    if (!event.body) {
      return buildErrorResponse(400, "Request body is required", correlationId);
    }

    let body: any;
    try {
      body = JSON.parse(event.body);
    } catch (parseError) {
      return buildErrorResponse(400, "Invalid JSON in request body", correlationId);
    }

    const userId = extractUserId(event);
    const validationError = validateIncidentRequest(body);
    if (validationError) {
      return buildErrorResponse(400, validationError, correlationId);
    }

    const timestamp = new Date().toISOString();

    // Generate sequential incident ID like INC-100001
    const incidentId = await generateIncidentId();

    // Create incident
    const incident: Incident = {
      incidentId: incidentId,
      firstName: body.firstName,
      lastName: body.lastName,
      gender: body.gender || Gender.MALE,
      dateOfBirth: body.dateOfBirth || "",
      contactNumber: body.contactNumber || "",
      email: body.email,
      communicationAddress: body.communicationAddress || "",
      incidentType: body.incidentType || "GENERAL",
      severity: body.severity || IncidentSeverity.MEDIUM,
      ssn: body.ssn || "",
      status: body.status || IncidentStatus.DRAFT,
      priority: body.priority || "MEDIUM",
      title: body.title || `Incident reported by ${body.firstName} ${body.lastName}`,
      description: body.description || "",
      reportedBy: userId,
      reportedAt: timestamp,
      createdAt: timestamp,
      updatedAt: timestamp,
      location: body.location,
      category: body.category,
      affectedPersons: body.affectedPersons || [],
      metadata: {
        ...body.metadata,
      },
      tenantId: body.tenantId || "",
      coverageType: body.coverageType,
    };

    console.log("Saving incident to DynamoDB", {
      email: incident.email,
      lastName: incident.lastName,
      incidentId: incident.incidentId,
      tableName: process.env.INCIDENTS_TABLE,
    });

    await docClient.send(
      new PutCommand({
        TableName: process.env.INCIDENTS_TABLE!,
        Item: incident,
      }),
    );

    console.log("Incident saved successfully - Event will be published automatically via DynamoDB Stream", {
      email: incident.email,
      lastName: incident.lastName,
      incidentId: incident.incidentId,
      correlationId,
    });

    return {
      statusCode: 201,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: true,
        message: "Incident created successfully",
        data: {
          incidentId: incident.incidentId,
          email: incident.email,
          lastName: incident.lastName,
          firstName: incident.firstName,
          status: incident.status,
          correlationId,
        },
        metadata: {
          timestamp: timestamp,
          requestId: context.awsRequestId,
        },
      }),
    };
  } catch (error: any) {
    console.error("Error in SaveIncident handler:", {
      error: error.message,
      stack: error.stack,
      correlationId,
      errorName: error.name,
    });

    if (error.name === "ResourceNotFoundException") {
      return buildErrorResponse(
        500,
        "DynamoDB table not found",
        correlationId,
        `Table: ${process.env.INCIDENTS_TABLE}`,
      );
    }

    if (error.name === "AccessDeniedException") {
      return buildErrorResponse(500, "Permission denied to write to DynamoDB", correlationId, error.message);
    }

    return buildErrorResponse(
      500,
      "Internal server error occurred while processing incident",
      correlationId,
      error.message,
    );
  }
};

function extractUserId(event: APIGatewayProxyEvent): string {
  if (event.requestContext.authorizer?.claims?.sub) {
    return event.requestContext.authorizer.claims.sub;
  }
  if (event.requestContext.authorizer?.principalId) {
    return event.requestContext.authorizer.principalId;
  }
  if (event.headers["X-User-ID"] || event.headers["x-user-id"]) {
    return event.headers["X-User-ID"] || event.headers["x-user-id"]!;
  }
  return "anonymous";
}

function validateIncidentRequest(body: any): string | null {
  const requiredFields = ["firstName", "lastName", "email", "gender", "dateOfBirth", "contactNumber"];

  for (const field of requiredFields) {
    if (!body[field] || (typeof body[field] === "string" && body[field].trim() === "")) {
      return `Missing required field: ${field}`;
    }
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(body.email)) {
    return "Invalid email address format";
  }

  if (body.severity && !Object.values(IncidentSeverity).includes(body.severity)) {
    return `Invalid severity. Allowed values: ${Object.values(IncidentSeverity).join(", ")}`;
  }

  if (body.status && !Object.values(IncidentStatus).includes(body.status)) {
    return `Invalid status. Allowed values: ${Object.values(IncidentStatus).join(", ")}`;
  }

  return null;
}

function buildErrorResponse(
  statusCode: number,
  message: string,
  correlationId: string,
  details?: string,
): APIGatewayProxyResult {
  return {
    statusCode,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      success: false,
      error: {
        message,
        details,
        correlationId,
        timestamp: new Date().toISOString(),
      },
    }),
  };
}
