import { Context } from "aws-lambda";
import { NotificationExecutor } from "../executors/NotificationExecutor";
import { Logger } from "../utils/logger.service";

const logger = new Logger("NotificationHandler");
const notificationExecutor = new NotificationExecutor();

export const handler = async (event: any, context: Context) => {
  logger.info("Notification handler invoked", {
    requestId: context.awsRequestId,
    stepName: event.stepName,
  });

  try {
    const { stepName, parameters, input } = event;
    const { eventDetail } = input;

    // Extract incident data from the workflow input
    const incidentData = eventDetail || {};

    logger.debug("Processing notification", {
      stepName,
      parameters,
      incidentEmail: incidentData.email,
    });

    // Map workflow parameters and incident data to notification input
    const notificationInput = {
      type: parameters.channel || "email",
      recipients: [incidentData.email || parameters.recipientEmail],
      subject: parameters.subject || `Incident ${incidentData.incidentId || "Processing"} - ${parameters.notificationType || "Notification"}`,
      message: parameters.message || buildNotificationMessage(incidentData, parameters),
      userId: incidentData.incidentId || `incident#${Date.now()}`,
      serviceName: parameters.serviceName || "DAP",
      from: parameters.fromEmail || "noreply@yourdomain.com",
      cc: parameters.ccEmail,
    };

    const result = await notificationExecutor.execute(notificationInput);

    logger.info("Notification handler completed", {
      success: result.success,
      messageId: result.messageId,
    });

    return {
      success: result.success,
      sent: result.sent,
      messageId: result.messageId,
      notificationType: parameters.notificationType,
      recipient: incidentData.email,
      timestamp: new Date().toISOString(),
    };
  } catch (error: any) {
    logger.error("Notification handler failed", {
      error: error.message,
      stack: error.stack,
    });

    return {
      success: false,
      sent: false,
      error: error.message,
      timestamp: new Date().toISOString(),
    };
  }
};

function buildNotificationMessage(incidentData: any, parameters: any): string {
  const notificationType = parameters.notificationType || "notification";

  switch (notificationType) {
    case "completion":
      return `
Dear ${incidentData.firstName} ${incidentData.lastName},

Your incident has been successfully processed.

Incident Details:
- Incident ID: ${incidentData.incidentId || "N/A"}
- Type: ${incidentData.incidentType || "N/A"}
- Severity: ${incidentData.severity || "N/A"}
- Status: ${incidentData.status || "COMPLETED"}

If you have any questions, please contact us.

Best regards,
DBHDS Team
      `.trim();

    case "validation":
      return `Incident validation completed for ${incidentData.firstName} ${incidentData.lastName}`;

    case "payment":
      return `Payment processed for incident ${incidentData.incidentId}`;

    default:
      return parameters.message || `Notification for incident ${incidentData.incidentId}`;
  }
}
