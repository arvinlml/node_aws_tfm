import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
import { randomUUID } from "crypto";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const EMPLOYEES_TABLE = process.env.EMPLOYEES_TABLE!;

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGINS || "*",
  "Access-Control-Allow-Headers":
    "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Correlation-ID",
  "Access-Control-Allow-Methods": "OPTIONS,POST,PUT",
  "Access-Control-Allow-Credentials": "true",
  "Content-Type": "application/json",
};

export const handler = async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  const correlationId = event.headers["X-Correlation-ID"] || event.headers["x-correlation-id"] || randomUUID();

  try {
    if (!event.body) return buildErrorResponse(400, "Request body is required", correlationId);

    let body: any;
    try {
      body = JSON.parse(event.body);
    } catch {
      return buildErrorResponse(400, "Invalid JSON in request body", correlationId);
    }

    const timestamp = new Date().toISOString();

    // PUT /employees/{id} — update (triggers MODIFY stream event → offboarding workflow)
    if (event.httpMethod === "PUT") {
      const employeeId = event.pathParameters?.id;
      if (!employeeId) return buildErrorResponse(400, "Missing employee ID in path", correlationId);

      await docClient.send(
        new UpdateCommand({
          TableName: EMPLOYEES_TABLE,
          Key: { employeeId },
          UpdateExpression:
            "SET #dept = :dept, #lastWorkingDay = :lastWorkingDay, #hasSystemAccess = :hasSystemAccess, #managerId = :managerId, #status = :status, #updatedAt = :updatedAt",
          ExpressionAttributeNames: {
            "#dept": "department",
            "#lastWorkingDay": "lastWorkingDay",
            "#hasSystemAccess": "hasSystemAccess",
            "#managerId": "managerId",
            "#status": "status",
            "#updatedAt": "updatedAt",
          },
          ExpressionAttributeValues: {
            ":dept": body.department,
            ":lastWorkingDay": body.lastWorkingDay,
            ":hasSystemAccess": body.hasSystemAccess ?? false,
            ":managerId": body.managerId ?? "",
            ":status": body.status ?? "OFFBOARDING",
            ":updatedAt": timestamp,
          },
        }),
      );

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          message: "Employee updated successfully — offboarding workflow will be triggered via stream",
          data: { employeeId, correlationId },
          metadata: { timestamp, requestId: context.awsRequestId },
        }),
      };
    }

    // POST /employees — create (triggers INSERT stream event → Employee Created)
    if (event.httpMethod === "POST") {
      const validationError = validateEmployeeRequest(body);
      if (validationError) return buildErrorResponse(400, validationError, correlationId);

      const employeeId = randomUUID();
      const employee = {
        employeeId,
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        department: body.department,
        jobTitle: body.jobTitle ?? "",
        employmentType: body.employmentType ?? "FULL_TIME",
        startDate: body.startDate,
        managerId: body.managerId ?? "",
        hasSystemAccess: body.hasSystemAccess ?? true,
        status: "ACTIVE",
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      await docClient.send(new PutCommand({ TableName: EMPLOYEES_TABLE, Item: employee }));

      return {
        statusCode: 201,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          message: "Employee created successfully",
          data: { employeeId, correlationId },
          metadata: { timestamp, requestId: context.awsRequestId },
        }),
      };
    }

    return buildErrorResponse(405, "Method Not Allowed", correlationId);
  } catch (error: any) {
    return buildErrorResponse(500, "Internal server error", correlationId, error.message);
  }
};

function validateEmployeeRequest(body: any): string | null {
  for (const field of ["firstName", "lastName", "email", "department", "startDate"]) {
    if (!body[field] || (typeof body[field] === "string" && body[field].trim() === "")) {
      return `Missing required field: ${field}`;
    }
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) return "Invalid email address format";
  return null;
}

function buildErrorResponse(
  statusCode: number,
  message: string,
  correlationId: string,
  details?: string,
): APIGatewayProxyResult {
  return {
    statusCode,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      success: false,
      error: { message, details, correlationId, timestamp: new Date().toISOString() },
    }),
  };
}
