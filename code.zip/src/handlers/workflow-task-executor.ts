import { Context } from "aws-lambda";
import { Logger } from "../utils/logger.service";
import {
  ValidationExecutor,
  NotificationExecutor,
  RuleExecutor,
  RoutingExecutor,
  DataPersistenceExecutor,
  IntegrationExecutor,
  HumanTaskExecutor,
  CustomActionExecutor,
} from "../executors";

const logger = new Logger("WorkflowTaskExecutor");

/**
 * WorkflowTaskExecutor — Lambda entry point for the Execution Layer
 *
 * Invoked by Step Functions for every TASK step. Dispatches to the
 * correct executor based on `executorType` set in the workflow step
 * parameters by WorkflowEngine (Orchestration Layer).
 *
 * Executor → Adapter/Domain mapping (per MMD design):
 *   DATA_PERSISTENCE → DatabaseAdapter → IncidentDomain | ApprovalDomain
 *   INTEGRATION      → ApiAdapter
 *   HUMAN_TASK       → DatabaseAdapter → UserDomain
 *   CUSTOM           → DatabaseAdapter → AuditDomain
 *   RULE             → RuleEngine (Orchestration Layer) → RULEDEF
 *   VALIDATION       → As of no validation logic implemneted, this is a CUSTOM action, but could be its own executor and domain if it grows in complexity.
 *   NOTIFICATION     → NotificationService
 *   ROUTING          → As of no validation logic implemneted, this is a CUSTOM action, but could be its own executor and domain if it grows in complexity.
 */
export const handler = async (event: any, context: Context) => {
  const { stepId, stepName, executorType = "CUSTOM", parameters = {}, input = {} } = event;

  logger.info("WorkflowTaskExecutor invoked", { requestId: context.awsRequestId, stepId, stepName, executorType });

  try {
    const result = await dispatch(executorType, parameters, input);
    logger.info("Step completed", { stepId, stepName, executorType, success: result.success });
    return result;
  } catch (error: any) {
    logger.error("Step failed", { stepId, stepName, executorType, error: error.message });
    return { success: false, error: error.message };
  }
};

async function dispatch(executorType: string, parameters: Record<string, any>, input: any): Promise<any> {
  const eventDetail = input?.eventDetail ?? {};

  switch (executorType.toUpperCase()) {
    case "VALIDATION":
      return new ValidationExecutor().execute({
        data: eventDetail,
        rules: parameters.validationRules ?? [],
        schema: parameters.schema,
      });

    case "NOTIFICATION":
      return new NotificationExecutor().execute({
        type: parameters.channel ?? "email",
        recipients: parameters.recipients ?? [],
        subject: parameters.subject,
        message: parameters.message ?? "",
        userId: parameters.userId,
        serviceName: parameters.serviceName,
        from: parameters.from,
        cc: parameters.cc,
        metadata: parameters.metadata,
      });

    case "RULE":
      return new RuleExecutor().execute({
        ruleId: parameters.ruleId,
        version: parameters.version,
        domain: parameters.domain ?? eventDetail.domain,
        context: eventDetail,
      });

    case "ROUTING":
      return new RoutingExecutor().execute({
        event: eventDetail,
        routingRules: parameters.routingRules ?? [],
        context: parameters.context,
      });

    case "DATA_PERSISTENCE":
      return new DataPersistenceExecutor().execute({
        action: parameters.action ?? "create",
        entity: parameters.entity ?? "unknown",
        data: eventDetail,
        id: parameters.id ?? eventDetail.incidentId ?? eventDetail.employeeId,
      });

    case "INTEGRATION":
      return new IntegrationExecutor().execute({
        service: parameters.service ?? "",
        endpoint: parameters.endpoint ?? "",
        method: parameters.method ?? "POST",
        payload: eventDetail,
        headers: parameters.headers,
      });

    case "HUMAN_TASK":
      return new HumanTaskExecutor().execute({
        taskId: parameters.taskId ?? `task-${Date.now()}`,
        taskType: parameters.taskType ?? "approval",
        assignee: parameters.assignee ?? "",
        description: parameters.description ?? "",
        entityId: eventDetail.incidentId ?? eventDetail.employeeId,
        dueDate: parameters.dueDate,
        metadata: parameters.metadata,
      });

    case "CUSTOM":
    default:
      return new CustomActionExecutor().execute({
        actionName: parameters.actionName ?? executorType,
        actionType: parameters.actionType ?? "generic",
        parameters,
        context: eventDetail,
      });
  }
}
