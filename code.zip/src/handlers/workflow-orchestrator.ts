import { Context } from "aws-lambda";
import { findWorkflowByEvent } from "../services/workflow-orchestration/workflow-finder.service";
import { WorkflowEngine } from "../services/workflow-orchestration/workflow-engine.service";
import { Logger } from "../utils/logger.service";

const logger = new Logger("WorkflowOrchestrator");

const WORKFLOW_METADATA_TABLE = process.env.WORKFLOW_METADATA_TABLE!;

const workflowEngine = new WorkflowEngine();

/**
 * WorkflowOrchestrator — Lambda entry point
 *
 * Thin handler that:
 *  1. Resolves the WorkflowDefinition (WFDEF) from the Configuration Layer
 *  2. Hands off to WorkflowEngine (Orchestration Layer) for execution
 *
 * No business logic lives here — all orchestration is in WorkflowEngine.
 */
export const handler = async (event: any, context: Context) => {
  const detailType: string = event["detail-type"];
  logger.info("WorkflowOrchestrator invoked", { requestId: context.awsRequestId, detailType });

  try {
    // Configuration Layer: resolve WFDEF by event type
    const workflow = await findWorkflowByEvent(detailType, WORKFLOW_METADATA_TABLE);

    if (!workflow) {
      logger.info("No workflow configured for event", { detailType });
      return { statusCode: 200, body: JSON.stringify({ message: "No matching workflow found" }) };
    }

    logger.info("Workflow resolved", { workflowId: workflow.workflowId, domain: workflow.domain });

    // Orchestration Layer: WorkflowEngine drives the execution
    const result = await workflowEngine.execute(workflow, event.detail);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Workflow execution started", ...result }),
    };
  } catch (error: any) {
    logger.error("WorkflowOrchestrator failed", { error: error.message, stack: error.stack });
    throw error;
  }
};
