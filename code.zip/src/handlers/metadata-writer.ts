import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
import { DynamoDBClient, PutItemCommand, UpdateItemCommand, GetItemCommand } from "@aws-sdk/client-dynamodb";
import { marshall } from "@aws-sdk/util-dynamodb";
import { v4 as uuidv4 } from "uuid";

const dynamoClient = new DynamoDBClient({});

interface SaveMetadataRequest {
  tableName?: string; // Optional: override default table
  metadata: {
    [key: string]: any;
  };
  options?: {
    mode?: "CREATE" | "UPDATE" | "UPSERT"; // Default: UPSERT
    generateKeys?: boolean; // Auto-generate PK/SK if not provided
    keyPrefix?: string; // Prefix for auto-generated keys
    overwrite?: boolean; // Allow overwriting existing items
  };
}

interface SaveMetadataResponse {
  success: boolean;
  message: string;
  data?: {
    [key: string]: any;
  };
  error?: string;
}

export const handler = async (event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult> => {
  console.log("Save Metadata - Received event:", JSON.stringify(event, null, 2));
  console.log("Save Metadata handler invoked", {
    requestId: context.awsRequestId,
    path: event.path,
    method: event.httpMethod,
  });
  try {
    // Parse request body
    if (!event.body) {
      return createResponse(400, {
        success: false,
        message: "Request body is required",
        error: "MISSING_BODY",
      });
    }

    const request: SaveMetadataRequest = JSON.parse(event.body);

    // Validate request
    if (!request.metadata) {
      return createResponse(400, {
        success: false,
        message: "metadata field is required in request body",
        error: "MISSING_METADATA",
      });
    }

    // Determine table name
    const tableName = request.tableName || event.pathParameters?.tableName || process.env.DEFAULT_METADATA_TABLE;

    if (!tableName) {
      return createResponse(400, {
        success: false,
        message: "Table name must be provided via tableName field, path parameter, or DEFAULT_METADATA_TABLE env var",
        error: "MISSING_TABLE_NAME",
      });
    }

    // Process metadata
    const processedMetadata = await processMetadata(request);

    // Save to DynamoDB
    const savedItem = await saveMetadata(tableName, processedMetadata, request.options);

    return createResponse(200, {
      success: true,
      message: "Metadata saved successfully",
      data: savedItem,
    });
  } catch (error: any) {
    console.error("Error saving metadata:", error);

    return createResponse(500, {
      success: false,
      message: "Failed to save metadata",
      error: error.message || "INTERNAL_ERROR",
    });
  }
};

async function processMetadata(request: SaveMetadataRequest): Promise<{ [key: string]: any }> {
  const { metadata, options } = request;
  const processed = { ...metadata };

  // Auto-generate keys if needed
  if (options?.generateKeys && (!processed.PK || !processed.SK)) {
    const keyPrefix = options.keyPrefix || metadata.type || "METADATA";
    const uniqueId = uuidv4().split("-")[0];

    if (!processed.PK) {
      processed.PK = `${keyPrefix}#${metadata.id || uniqueId}`;
    }
    if (!processed.SK) {
      processed.SK = metadata.version || "METADATA";
    }
  }

  // Add metadata timestamps
  const now = new Date().toISOString();
  if (!processed.createdAt) {
    processed.createdAt = now;
  }
  processed.updatedAt = now;

  return processed;
}

async function saveMetadata(
  tableName: string,
  metadata: Record<string, any>,
  options?: SaveMetadataRequest["options"],
): Promise<Record<string, any>> {
  // UPSERT mode: create or update
  await dynamoClient.send(
    new PutItemCommand({
      TableName: tableName,
      Item: marshall(metadata, { removeUndefinedValues: true }),
    }),
  );

  return metadata;
}

function createResponse(statusCode: number, body: SaveMetadataResponse): APIGatewayProxyResult {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
      "Access-Control-Allow-Methods": "POST,OPTIONS",
    },
    body: JSON.stringify(body, null, 2),
  };
}
