export const config = {
  aws: {
    region: process.env.AWS_REGION || "us-east-1",
    dynamodb: {
      tableName: process.env.DYNAMODB_TABLE_NAME || "incidents",
      endpoint: process.env.DYNAMODB_ENDPOINT, // For local testing
    },
    eventBridge: {
      busName: process.env.EVENT_BUS_NAME || "workflow-framework-event-bus",
    },
  },
  notification: {
    apiEndpoint: process.env.NOTIFICATION_API_ENDPOINT || "https://nckvixvu0b.execute-api.us-east-1.amazonaws.com/dev/notifications/send",
  },
  app: {
    environment: process.env.ENVIRONMENT || "development",
    logLevel: process.env.LOG_LEVEL || "info",
    enableEncryption: process.env.ENABLE_ENCRYPTION === "true",
  },
  security: {
    encryptionKey: process.env.ENCRYPTION_KEY,
    ssnSalt: process.env.SSN_SALT || "default-salt-change-in-production",
  },
};
