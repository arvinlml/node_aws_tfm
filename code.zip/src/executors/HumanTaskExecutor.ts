import { Logger } from "../utils/logger.service";
import { DynamoDBAdapter } from "../adapters/database/DynamoDBAdapter";
import { UserDomain } from "../services/domain/UserDomain";

const logger = new Logger("HumanTaskExecutor");

export interface HumanTaskInput {
  taskId: string;
  taskType: "approval" | "review" | "decision" | "input";
  assignee: string;
  description: string;
  entityId?: string;
  dueDate?: string;
  metadata?: any;
}

export interface HumanTaskOutput {
  success: boolean;
  taskCreated: boolean;
  taskId?: string;
  status?: string;
  error?: string;
}

/**
 * HumanTaskExecutor — Execution Layer
 *
 * Delegates to UserDomain (Business Logic Layer) via the DatabaseAdapter
 * (Adapter Layer) per the MMD design: HumanTaskExecutor → UserDomain.
 */
export class HumanTaskExecutor {
  private readonly userDomain: UserDomain;

  constructor() {
    this.userDomain = new UserDomain(new DynamoDBAdapter());
  }

  async execute(input: HumanTaskInput): Promise<HumanTaskOutput> {
    logger.info("HumanTaskExecutor started", { taskId: input.taskId, taskType: input.taskType, assignee: input.assignee });

    try {
      const task = await this.userDomain.assignTask({
        taskId: input.taskId,
        taskType: input.taskType,
        assignee: input.assignee,
        description: input.description,
        entityId: input.entityId ?? input.taskId,
        dueDate: input.dueDate,
        metadata: input.metadata,
      });

      logger.info("HumanTaskExecutor completed", { taskId: task.taskId, status: task.status });
      return { success: true, taskCreated: true, taskId: task.taskId ?? input.taskId, status: task.status };
    } catch (error: any) {
      logger.error("HumanTaskExecutor failed", { error: error.message, stack: error.stack });
      return { success: false, taskCreated: false, error: error.message };
    }
  }
}
