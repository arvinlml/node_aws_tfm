import { Logger } from "../utils/logger.service";
import { DatabaseAdapter, DynamoDBAdapter } from "../adapters/database/DynamoDBAdapter";
import { IncidentDomain } from "../services/domain/IncidentDomain";
import { ApprovalDomain } from "../services/domain/ApprovalDomain";

const logger = new Logger("DataPersistenceExecutor");

export interface DataPersistenceInput {
  action: "create" | "update" | "delete" | "read";
  /** Domain entity to operate on: "incident" | "approval" */
  entity: string;
  data?: Record<string, any>;
  id?: string;
}

export interface DataPersistenceOutput {
  success: boolean;
  data?: any;
  error?: string;
}

/**
 * DataPersistenceExecutor — Execution Layer
 *
 * Routes through the pluggable DatabaseAdapter (Adapter Layer) and
 * delegates to the appropriate domain service (Business Logic Layer):
 *   - entity "incident"  → IncidentDomain
 *   - entity "approval"  → ApprovalDomain
 */
export class DataPersistenceExecutor {
  private readonly db: DatabaseAdapter;
  private readonly incidentDomain: IncidentDomain;
  private readonly approvalDomain: ApprovalDomain;

  constructor(db: DatabaseAdapter = new DynamoDBAdapter()) {
    this.db = db;
    this.incidentDomain = new IncidentDomain(this.db);
    this.approvalDomain = new ApprovalDomain(this.db);
  }

  async execute(input: DataPersistenceInput): Promise<DataPersistenceOutput> {
    logger.info("DataPersistenceExecutor started", { action: input.action, entity: input.entity });

    try {
      const result = await this.dispatch(input);
      logger.info("DataPersistenceExecutor completed", { entity: input.entity, action: input.action });
      return { success: true, data: result };
    } catch (error: any) {
      logger.error("DataPersistenceExecutor failed", { error: error.message, stack: error.stack });
      return { success: false, error: error.message };
    }
  }

  private async dispatch(input: DataPersistenceInput): Promise<any> {
    switch (input.entity) {
      case "incident":
        return this.handleIncident(input);
      case "approval":
        return this.handleApproval(input);
      default:
        // Generic fallback — direct adapter call for unknown entities
        logger.warn("Unknown entity, using generic adapter", { entity: input.entity });
        return this.handleGeneric(input);
    }
  }

  private async handleIncident(input: DataPersistenceInput): Promise<any> {
    switch (input.action) {
      case "create": return this.incidentDomain.create(input.data ?? {});
      case "update": return this.incidentDomain.update(input.id!, input.data ?? {});
      case "read":   return this.incidentDomain.get(input.id!);
      case "delete": return this.incidentDomain.delete(input.id!);
    }
  }

  private async handleApproval(input: DataPersistenceInput): Promise<any> {
    switch (input.action) {
      case "create": return this.approvalDomain.createApproval(input.data as any);
      case "update": return this.approvalDomain.updateStatus(input.id!, input.data?.status, input.data?.comments);
      case "read":   return this.approvalDomain.get(input.id!);
      default:       throw new Error(`Unsupported action '${input.action}' for approval entity`);
    }
  }

  private async handleGeneric(input: DataPersistenceInput): Promise<any> {
    const table = process.env[`${input.entity.toUpperCase()}_TABLE`] ?? input.entity;
    switch (input.action) {
      case "create": return this.db.put(table, input.data ?? {});
      case "update": return this.db.update(table, { id: input.id }, input.data ?? {});
      case "read":   return this.db.get(table, { id: input.id });
      case "delete": return this.db.delete(table, { id: input.id });
    }
  }
}
