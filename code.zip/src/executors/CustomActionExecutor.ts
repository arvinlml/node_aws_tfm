import { v4 as uuidv4 } from "uuid";
import { Logger } from "../utils/logger.service";
import { DynamoDBAdapter } from "../adapters/database/DynamoDBAdapter";
import { AuditDomain } from "../services/domain/AuditDomain";

const logger = new Logger("CustomActionExecutor");

export interface CustomActionInput {
  actionName: string;
  actionType: string;
  parameters: Record<string, any>;
  context?: Record<string, any>;
}

export interface CustomActionOutput {
  success: boolean;
  result?: any;
  error?: string;
}

/**
 * CustomActionExecutor — Execution Layer
 *
 * Executes custom domain actions and writes an audit trail via
 * AuditDomain (Business Logic Layer) per the MMD design:
 * CustomActionExecutor → AuditDomain.
 */
export class CustomActionExecutor {
  private readonly auditDomain: AuditDomain;

  constructor() {
    this.auditDomain = new AuditDomain(new DynamoDBAdapter());
  }

  async execute(input: CustomActionInput): Promise<CustomActionOutput> {
    logger.info("CustomActionExecutor started", { actionName: input.actionName, actionType: input.actionType });

    try {
      const result = await this.runAction(input);

      // Always write an audit entry for every custom action
      await this.auditDomain.log({
        auditId: uuidv4(),
        entityId: input.context?.entityId ?? input.context?.incidentId ?? input.context?.employeeId ?? "unknown",
        entityType: input.parameters?.entityType ?? "unknown",
        action: input.actionName,
        performedBy: input.parameters?.performedBy ?? "workflow-engine",
        domain: input.parameters?.domain ?? "unknown",
        before: input.context,
        after: result,
        metadata: input.parameters,
      });

      logger.info("CustomActionExecutor completed", { actionName: input.actionName });
      return { success: true, result };
    } catch (error: any) {
      logger.error("CustomActionExecutor failed", { error: error.message, stack: error.stack });
      return { success: false, error: error.message };
    }
  }

  private async runAction(input: CustomActionInput): Promise<any> {
    // Extensible: add named action handlers here as the system grows
    switch (input.actionType) {
      case "audit_log":
        return { logged: true, actionName: input.actionName };
      default:
        logger.debug("Executing generic custom action", { actionType: input.actionType });
        return { executed: true, actionName: input.actionName, parameters: input.parameters };
    }
  }
}
