import { Logger } from "../utils/logger.service";
import { RuleEngine, RuleEvaluationResult } from "../services/workflow-orchestration/rule-engine.service";

const logger = new Logger("RuleExecutor");

export interface RuleInput {
  /** ID of a specific rule to evaluate, or omit to evaluate all rules for the domain */
  ruleId?: string;
  version?: number;
  /** Domain used to load all active rules when ruleId is not provided */
  domain?: string;
  /** The entity data to evaluate conditions against */
  context: Record<string, any>;
}

export interface RuleOutput {
  success: boolean;
  results: RuleEvaluationResult[];
  /** Aggregated actions from all matched rules */
  matchedActions: any[];
  error?: string;
}

/**
 * RuleExecutor — Execution Layer
 *
 * Delegates to the RuleEngine (Orchestration Layer) which loads
 * rule definitions from the Configuration Layer (RULEDEF / workflow-rules table).
 */
export class RuleExecutor {
  private readonly ruleEngine: RuleEngine;

  constructor() {
    this.ruleEngine = new RuleEngine();
  }

  async execute(input: RuleInput): Promise<RuleOutput> {
    logger.info("RuleExecutor started", { ruleId: input.ruleId, domain: input.domain });

    try {
      let results: RuleEvaluationResult[];

      if (input.ruleId) {
        const rule = await this.ruleEngine.loadRule(input.ruleId, input.version ?? 1);
        if (!rule) {
          return { success: false, results: [], matchedActions: [], error: `Rule not found: ${input.ruleId}` };
        }
        results = [this.ruleEngine.evaluate(rule, input.context)];
      } else if (input.domain) {
        results = await this.ruleEngine.evaluateForDomain(input.domain, input.context);
      } else {
        return { success: false, results: [], matchedActions: [], error: "Provide ruleId or domain" };
      }

      const matchedActions = results.filter((r) => r.matched).flatMap((r) => r.actions);
      logger.info("RuleExecutor completed", { totalRules: results.length, matchedCount: matchedActions.length });

      return { success: true, results, matchedActions };
    } catch (error: any) {
      logger.error("RuleExecutor failed", { error: error.message, stack: error.stack });
      return { success: false, results: [], matchedActions: [], error: error.message };
    }
  }
}
