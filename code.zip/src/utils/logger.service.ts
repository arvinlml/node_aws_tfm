export enum LogLevel {
  DEBUG = "DEBUG",
  INFO = "INFO",
  WARN = "WARN",
  ERROR = "ERROR",
}

export class Logger {
  public context: unknown;

  constructor(context: unknown = "Application") {
    this.context = context;
  }

  public log(level: LogLevel, message: string, meta?: any) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      level,
      context: this.context,
      message,
      ...(meta && { meta }),
    };

    console.log(JSON.stringify(logEntry));
  }

  debug(message: string, meta?: any) {
    this.log(LogLevel.DEBUG, message, meta);
  }

  info(message: string, meta?: any) {
    this.log(LogLevel.INFO, message, meta);
  }

  warn(message: string, meta?: any) {
    this.log(LogLevel.WARN, message, meta);
  }

  error(message: string, metaOrError?: any) {
    let meta: any = {};

    // If second parameter is an Error, extract error details
    if (metaOrError instanceof Error) {
      meta.error = {
        name: metaOrError.name,
        message: metaOrError.message,
        stack: metaOrError.stack,
      };
    } else if (metaOrError) {
      // Otherwise, treat it as metadata
      meta = metaOrError;
    }

    this.log(LogLevel.ERROR, message, meta);
  }
}

export const createLogger = (context: unknown) => new Logger(context);
