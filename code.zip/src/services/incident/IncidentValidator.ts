import Joi from "joi";
import {
  Gender,
  Incident,
  IncidentType,
  IncidentSeverity,
} from "../../types/incident.types";
import { Logger } from "../../utils/logger.service";

const incidentSchema = Joi.object({
  firstName: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .pattern(/^[a-zA-Z\s'-]+$/)
    .required()
    .messages({
      "string.pattern.base":
        "First name can only contain letters, spaces, hyphens, and apostrophes",
      "string.empty": "First name is required",
      "string.min": "First name must be at least 1 character",
      "string.max": "First name must not exceed 100 characters",
    }),

  lastName: Joi.string()
    .trim()
    .min(1)
    .max(100)
    .pattern(/^[a-zA-Z\s'-]+$/)
    .required()
    .messages({
      "string.pattern.base":
        "Last name can only contain letters, spaces, hyphens, and apostrophes",
      "string.empty": "Last name is required",
    }),

  gender: Joi.string()
    .valid(...Object.values(Gender))
    .required()
    .messages({
      "any.only": `Gender must be one of: ${Object.values(Gender).join(", ")}`,
    }),

  dateOfBirth: Joi.string()
    .isoDate()
    .required()
    .custom((value, helpers) => {
      const dob = new Date(value);
      const now = new Date();
      const age = now.getFullYear() - dob.getFullYear();

      if (dob > now) {
        return helpers.error("date.future");
      }

      if (age > 150) {
        return helpers.error("date.tooOld");
      }

      return value;
    })
    .messages({
      "string.isoDate": "Date of birth must be in ISO 8601 format (YYYY-MM-DD)",
      "date.future": "Date of birth cannot be in the future",
      "date.tooOld": "Date of birth is not valid",
    }),
  contactNumber: Joi.string()
    .trim()
    .pattern(/^[\d\s\-\+$$]+$/)
    .min(10)
    .max(20)
    .required()
    .messages({
      "string.pattern.base": "Contact number must be a valid phone number",
      "string.min": "Contact number must be at least 10 characters",
    }),

  emailAddress: Joi.string()
    .trim()
    .email()
    .lowercase()
    .max(255)
    .required()
    .messages({ "string.email": "Email address must be valid" }),

  communicationAddress: Joi.string()
    .trim()
    .min(10)
    .max(500)
    .required()
    .messages({
      "string.min": "Communication address must be at least 10 characters",
      "string.max": "Communication address must not exceed 500 characters",
    }),

  incidentType: Joi.string()
    .valid(...Object.values(IncidentType))
    .required()
    .messages({
      "any.only": `Incident type must be one of: ${Object.values(IncidentType).join(", ")}`,
    }),

  severity: Joi.string()
    .valid(...Object.values(IncidentSeverity))
    .required()
    .messages({
      "any.only": `Severity must be one of: ${Object.values(IncidentSeverity).join(", ")}`,
    }),

  ssn: Joi.string()
    .trim()
    .pattern(/^\d{3}-?\d{2}-?\d{4}$/)
    .required()
    .messages({
      "string.pattern.base": "SSN must be in format XXX-XX-XXXX or XXXXXXXXX",
      "string.empty": "SSN is required",
    }),

  description: Joi.string()
    .trim()
    .max(2000)
    .optional()
    .messages({ "string.max": "Description must not exceed 2000 characters" }),
  reportedBy: Joi.string().trim().max(255).optional(),
});

export class IncidentValidator {
  static validate(input: unknown): Incident {
    const { error, value } = incidentSchema.validate(input, {
      abortEarly: false,
      stripUnknown: true,
    });

    if (error) {
      const details = error.details.map((detail) => ({
        field: detail.path.join("."),
        message: detail.message,
      }));
      throw error.message;
    }
    return value;
  }

  static sanitizeSSN(ssn: string): string {
    // Remove all non-digit characters
    return ssn.replace(/\D/g, "");
  }

  static formatSSN(ssn: string): string {
    // Format as XXX-XX-XXXX
    const sanitized = this.sanitizeSSN(ssn);
    return `${sanitized.slice(0, 3)}-${sanitized.slice(3, 5)}-${sanitized.slice(5)}`;
  }
}
