import { DatabaseAdapter } from "../../adapters/database/DynamoDBAdapter";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("ApprovalDomain");

const WORKFLOW_EXECUTIONS_TABLE = process.env.WORKFLOW_EXECUTIONS_TABLE!;

export type ApprovalStatus = "PENDING" | "APPROVED" | "REJECTED";

export class ApprovalDomain {
  constructor(private readonly db: DatabaseAdapter) {}

  async createApproval(data: {
    approvalId: string;
    entityId: string;
    entityType: string;
    assignee: string;
    requestedBy: string;
    metadata?: Record<string, any>;
  }): Promise<Record<string, any>> {
    logger.info("Creating approval record", { approvalId: data.approvalId });
    const item = {
      ...data,
      status: "PENDING" as ApprovalStatus,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await this.db.put(WORKFLOW_EXECUTIONS_TABLE, item);
    return item;
  }

  async updateStatus(approvalId: string, status: ApprovalStatus, comments?: string): Promise<void> {
    logger.info("Updating approval status", { approvalId, status });
    await this.db.update(
      WORKFLOW_EXECUTIONS_TABLE,
      { executionId: approvalId },
      { status, ...(comments && { comments }), updatedAt: new Date().toISOString() }
    );
  }

  async get(approvalId: string): Promise<Record<string, any> | null> {
    return this.db.get(WORKFLOW_EXECUTIONS_TABLE, { executionId: approvalId });
  }
}
