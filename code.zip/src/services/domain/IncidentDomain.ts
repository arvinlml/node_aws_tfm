import { DatabaseAdapter } from "../../adapters/database/DynamoDBAdapter";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("IncidentDomain");

const INCIDENTS_TABLE = process.env.INCIDENTS_TABLE!;

export class IncidentDomain {
  constructor(private readonly db: DatabaseAdapter) {}

  async create(data: Record<string, any>): Promise<Record<string, any>> {
    logger.info("Creating incident", { incidentId: data.incidentId });
    const item = { ...data, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    await this.db.put(INCIDENTS_TABLE, item);
    return item;
  }

  async update(incidentId: string, updates: Record<string, any>): Promise<void> {
    logger.info("Updating incident", { incidentId });
    await this.db.update(INCIDENTS_TABLE, { incidentId }, { ...updates, updatedAt: new Date().toISOString() });
  }

  async get(incidentId: string): Promise<Record<string, any> | null> {
    logger.info("Fetching incident", { incidentId });
    return this.db.get(INCIDENTS_TABLE, { incidentId });
  }

  async delete(incidentId: string): Promise<void> {
    logger.info("Deleting incident", { incidentId });
    await this.db.delete(INCIDENTS_TABLE, { incidentId });
  }
}
