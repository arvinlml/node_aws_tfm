import { DatabaseAdapter } from "../../adapters/database/DynamoDBAdapter";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("UserDomain");

const WORKFLOW_EXECUTIONS_TABLE = process.env.WORKFLOW_EXECUTIONS_TABLE!;

export class UserDomain {
  constructor(private readonly db: DatabaseAdapter) {}

  async assignTask(data: {
    taskId: string;
    taskType: string;
    assignee: string;
    description: string;
    entityId: string;
    dueDate?: string;
    metadata?: Record<string, any>;
  }): Promise<Record<string, any>> {
    logger.info("Assigning human task", { taskId: data.taskId, assignee: data.assignee });
    const item = {
      executionId: data.taskId,
      ...data,
      status: "PENDING",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await this.db.put(WORKFLOW_EXECUTIONS_TABLE, item);
    return item;
  }

  async completeTask(taskId: string, outcome: "APPROVED" | "REJECTED", notes?: string): Promise<void> {
    logger.info("Completing human task", { taskId, outcome });
    await this.db.update(
      WORKFLOW_EXECUTIONS_TABLE,
      { executionId: taskId },
      { status: outcome, ...(notes && { notes }), updatedAt: new Date().toISOString() }
    );
  }
}
