import {
  SFNClient,
  StartExecutionCommand,
  CreateStateMachineCommand,
  DescribeStateMachineCommand,
  UpdateStateMachineCommand,
} from "@aws-sdk/client-sfn";
import { v4 as uuidv4 } from "uuid";
import { WorkflowDefinition, WorkflowStep } from "../../types/workflow-orchestration.types";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("WorkflowEngine");

const STATE_MACHINE_ROLE_ARN = process.env.STATE_MACHINE_ROLE_ARN!;
const ACCOUNT_ID = process.env.ACCOUNT_ID!;
const AWS_REGION = process.env.AWS_REGION ?? "us-east-1";

export interface WorkflowExecutionResult {
  executionArn: string;
  workflowId: string;
  workflowName: string;
}

/**
 * WorkflowEngine — Orchestration Layer
 *
 * Consumes a WorkflowDefinition (WFDEF from Configuration Layer) and:
 *  1. Generates a Step Functions state machine from the definition
 *  2. Ensures the state machine exists (create or update)
 *  3. Starts an execution, passing the event detail as input
 *
 * Each state machine task invokes the workflow-task-executor Lambda which
 * dispatches to the correct Execution Layer executor based on executorType.
 */
export class WorkflowEngine {
  private readonly sfn = new SFNClient({});

  async execute(workflow: WorkflowDefinition, eventDetail: any): Promise<WorkflowExecutionResult> {
    logger.info("WorkflowEngine executing", { workflowId: workflow.workflowId, domain: workflow.domain });

    const definition = this.buildStateMachineDefinition(workflow);
    const stateMachineArn = await this.ensureStateMachine(workflow, definition);
    const executionArn = await this.startExecution(stateMachineArn, workflow, eventDetail);

    logger.info("Workflow execution started", { executionArn });
    return { executionArn, workflowId: workflow.workflowId, workflowName: workflow.workflowName };
  }

  private buildStateMachineDefinition(workflow: WorkflowDefinition): string {
    const states: Record<string, any> = {};

    workflow.steps.forEach((step, index) => {
      const isLast = index === workflow.steps.length - 1;
      const defaultNext = isLast ? "WorkflowSuccess" : (step.nextStep ?? workflow.steps[index + 1].stepName);

      switch (step.stepType) {
        case "TASK":
          states[step.stepName] = this.buildTaskState(step, workflow, defaultNext);
          break;
        case "CHOICE":
          states[step.stepName] = this.buildChoiceState(step);
          break;
        case "PARALLEL":
          states[step.stepName] = this.buildParallelState(step, defaultNext);
          break;
        case "WAIT":
          states[step.stepName] = { Type: "Wait", Seconds: step.parameters?.seconds ?? 60, Next: defaultNext };
          break;
        case "PASS":
          states[step.stepName] = {
            Type: "Pass",
            Result: step.parameters ?? {},
            ResultPath: `$.steps.${step.stepName}`,
            Next: defaultNext,
          };
          break;
      }
    });

    states["WorkflowSuccess"] = { Type: "Succeed" };

    return JSON.stringify({
      Comment: `${workflow.domain} — ${workflow.workflowName}`,
      StartAt: workflow.steps[0].stepName,
      States: states,
      TimeoutSeconds: workflow.configuration.timeout,
    });
  }

  private buildTaskState(step: WorkflowStep, workflow: WorkflowDefinition, defaultNext: string): any {
    return {
      Type: "Task",
      Resource: "arn:aws:states:::lambda:invoke",
      Parameters: {
        FunctionName: `${step.executor}:$LATEST`,
        Payload: {
          "executionId.$": "$$.Execution.Name",
          stepId: step.stepId,
          stepName: step.stepName,
          // executorType drives dispatch in the Execution Layer
          executorType: step.parameters?.executorType ?? "CUSTOM",
          parameters: step.parameters ?? {},
          "input.$": "$",
        },
      },
      ResultPath: `$.results.${step.stepId.replace(/-/g, "_")}`,
      ResultSelector: { "output.$": "$.Payload" },
      Retry: [
        {
          ErrorEquals: ["States.TaskFailed", "States.Timeout"],
          IntervalSeconds: 2,
          MaxAttempts: step.errorHandler?.retries ?? workflow.configuration.retryPolicy.maxAttempts,
          BackoffRate: workflow.configuration.retryPolicy.backoffRate,
        },
      ],
      ...(step.errorHandler?.fallbackStep && {
        Catch: [{ ErrorEquals: ["States.ALL"], Next: step.errorHandler.fallbackStep, ResultPath: "$.error" }],
      }),
      Next: defaultNext,
      TimeoutSeconds: 300,
    };
  }

  private buildChoiceState(step: WorkflowStep): any {
    return {
      Type: "Choice",
      Choices: (step.choices ?? []).map((c) => {
        const parts = c.condition.split(" ");
        return {
          Variable: parts[0],
          StringEquals: parts[2]?.replace(/['"]/g, ""),
          Next: c.nextStep,
        };
      }),
      Default: step.nextStep ?? "WorkflowSuccess",
    };
  }

  private buildParallelState(step: WorkflowStep, defaultNext: string): any {
    return {
      Type: "Parallel",
      Branches: (step.branches ?? []).map((branch) => ({
        StartAt: branch[0].stepName,
        States: Object.fromEntries(
          branch.map((s, i) => [
            s.stepName,
            {
              Type: "Task",
              Resource: "arn:aws:states:::lambda:invoke",
              Parameters: {
                FunctionName: `${s.executor}:$LATEST`,
                Payload: { stepId: s.stepId, executorType: s.parameters?.executorType ?? "CUSTOM", parameters: s.parameters ?? {}, "input.$": "$" },
              },
              ...(i === branch.length - 1 ? { End: true } : { Next: branch[i + 1].stepName }),
            },
          ])
        ),
      })),
      ResultPath: `$.results.${step.stepId.replace(/-/g, "_")}`,
      Next: defaultNext,
    };
  }

  private async ensureStateMachine(workflow: WorkflowDefinition, definition: string): Promise<string> {
    const name = `workflow-${workflow.workflowId}`;
    const arn = `arn:aws:states:${AWS_REGION}:${ACCOUNT_ID}:stateMachine:${name}`;

    try {
      const existing = await this.sfn.send(new DescribeStateMachineCommand({ stateMachineArn: arn }));
      await this.sfn.send(new UpdateStateMachineCommand({ stateMachineArn: existing.stateMachineArn, definition, roleArn: STATE_MACHINE_ROLE_ARN }));
      logger.info("State machine updated", { name });
      return existing.stateMachineArn!;
    } catch (err: any) {
      if (err.name !== "StateMachineDoesNotExist") throw err;
      const created = await this.sfn.send(
        new CreateStateMachineCommand({
          name,
          definition,
          roleArn: STATE_MACHINE_ROLE_ARN,
          type: "STANDARD",
          tags: [
            { key: "WorkflowId", value: workflow.workflowId },
            { key: "Domain", value: workflow.domain },
          ].filter(t => t.key && t.value),
        })
      );
      logger.info("State machine created", { name });
      return created.stateMachineArn!;
    }
  }

  private async startExecution(stateMachineArn: string, workflow: WorkflowDefinition, eventDetail: any): Promise<string> {
    const uuid = uuidv4();
    const truncated = workflow.workflowId.substring(0, 38);
    const res = await this.sfn.send(
      new StartExecutionCommand({
        stateMachineArn,
        name: `exec-${truncated}-${uuid}`,
        input: JSON.stringify({
          workflowId: workflow.workflowId,
          workflowName: workflow.workflowName,
          domain: workflow.domain,
          eventDetail,
          startTime: new Date().toISOString(),
        }),
      })
    );
    return res.executionArn!;
  }
}
