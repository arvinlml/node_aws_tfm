import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";
import { WorkflowDefinition } from "../../types/workflow-orchestration.types";

const dynamoClient = new DynamoDBClient({});

/**
 * Finds workflow definition by matching event type to workflow trigger events
 * This makes the framework completely generic - no hardcoded workflow IDs!
 */
export async function findWorkflowByEvent(
  eventType: string,
  tableName: string
): Promise<WorkflowDefinition | null> {
  console.log("Searching for workflow matching event", { eventType, tableName });

  try {
    // Scan all active workflows (in production, use GSI on status + triggerEvents)
    const response = await dynamoClient.send(
      new ScanCommand({
        TableName: tableName,
        FilterExpression: "#status = :active",
        ExpressionAttributeNames: {
          "#status": "status",
        },
        ExpressionAttributeValues: {
          ":active": { S: "ACTIVE" },
        },
      })
    );

    if (!response.Items || response.Items.length === 0) {
      console.log("No active workflows found");
      return null;
    }

    // Find workflow that matches the event type
    for (const item of response.Items) {
      const raw = unmarshall(item) as any;
      const workflow = (raw.metadata ?? raw) as WorkflowDefinition;

      // Check if this workflow is triggered by the event
      if (workflow.triggerEvents && workflow.triggerEvents.includes(eventType)) {
        console.log("Found matching workflow", {
          workflowId: workflow.workflowId,
          workflowName: workflow.workflowName,
          eventType,
        });
        return workflow;
      }
    }

    console.log("No workflow found for event type", { eventType });
    return null;
  } catch (error) {
    console.error("Error finding workflow by event:", error);
    throw error;
  }
}

/**
 * Alternative: Find workflow by explicit ID (for manual triggers)
 */
export async function findWorkflowById(
  workflowId: string,
  version: number,
  tableName: string
): Promise<WorkflowDefinition | null> {
  console.log("Fetching workflow by ID", { workflowId, version, tableName });

  try {
    const { GetItemCommand } = await import("@aws-sdk/client-dynamodb");
    
    const response = await dynamoClient.send(
      new GetItemCommand({
        TableName: tableName,
        Key: {
          workflowId: { S: workflowId },
          version: { N: String(version) },
        },
      })
    );

    if (!response.Item) {
      console.log("Workflow not found", { workflowId, version });
      return null;
    }

    const raw = unmarshall(response.Item) as any;
    return (raw.metadata ?? raw) as WorkflowDefinition;
  } catch (error) {
    console.error("Error fetching workflow by ID:", error);
    throw error;
  }
}
