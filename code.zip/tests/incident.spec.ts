import { IncidentValidator } from "../src/services/incident/IncidentValidator";
import {
  Gender,
  IncidentType,
  IncidentSeverity,
} from "../src/types/incident.types";
describe("IncidentValidator", () => {
  describe("validate", () => {
    const validInput = {
      firstName: "John",
      lastName: "Doe",
      gender: Gender.MALE,
      dateOfBirth: "1990-01-15",
      contactNumber: "+1-555-123-4567",
      email: "john.doe@example.com",
      emailAddress: "john.doe@example.com",
      communicationAddress: "123 Main St, Springfield, IL 62701",
      incidentType: IncidentType.MEDICAL,
      severity: IncidentSeverity.HIGH,
      ssn: "123-45-6789",
    };

    it("should validate correct input successfully", () => {
      const result = IncidentValidator.validate(validInput);
      expect(result).toBeDefined();
      // console.log(JSON.stringify(result));
      expect(result.firstName).toBe("John");
      // expect(result.emailAddress).toBe("john.doe@example.com");
    });

    it("should validate future date input", () => {
      const invalidInput = { ...validInput };
      invalidInput.dateOfBirth = "2130-01-15";
      expect(() => IncidentValidator.validate(invalidInput)).toThrow();
    });

    it("should validate age too old", () => {
      const invalidInput = { ...validInput };
      invalidInput.dateOfBirth = "1890-01-15";
      expect(() => IncidentValidator.validate(invalidInput)).toThrow();
    });

    it("should throw ValidationError for missing required fields", () => {
      const invalidInput = { ...validInput };
      delete (invalidInput as any).firstName;
      expect(() => IncidentValidator.validate(invalidInput)).toThrow();
    });

    it("should throw ValidationError for invalid email", () => {
      const invalidInput = { ...validInput, emailAddress: "invalid-email" };
      expect(() => IncidentValidator.validate(invalidInput)).toBeDefined();
    });

    it("should throw ValidationError for invalid SSN format", () => {
      const invalidInput = { ...validInput, ssn: "123-456-789" };

      expect(() => IncidentValidator.validate(invalidInput)).toBeDefined();
    });

    it("should throw ValidationError for future date of birth", () => {
      const futureDate = new Date();
      futureDate.setFullYear(futureDate.getFullYear() + 1);
      const invalidInput = {
        ...validInput,
        dateOfBirth: futureDate.toISOString().split("T")[0],
      };

      expect(() => IncidentValidator.validate(invalidInput)).toBeDefined();
    });

    it("should throw ValidationError for invalid gender", () => {
      const invalidInput = { ...validInput, gender: "INVALID" as any };

      expect(() => IncidentValidator.validate(invalidInput)).toBeDefined();
    });

    it("should accept valid SSN with or without dashes", () => {
      const input1 = { ...validInput, ssn: "123-45-6789" };
      const input2 = { ...validInput, ssn: "123456789" };

      expect(() => IncidentValidator.validate(input1)).not.toThrow();
      expect(() => IncidentValidator.validate(input2)).not.toThrow();
    });
  });

  describe("sanitizeSSN", () => {
    it("should remove all non-digit characters from SSN", () => {
      expect(IncidentValidator.sanitizeSSN("123-45-6789")).toBe("123456789");
      expect(IncidentValidator.sanitizeSSN("123 45 6789")).toBe("123456789");
      expect(IncidentValidator.sanitizeSSN("123.45.6789")).toBe("123456789");
    });
  });

  describe("formatSSN", () => {
    it("should format SSN as XXX-XX-XXXX", () => {
      expect(IncidentValidator.formatSSN("123456789")).toBe("123-45-6789");
      expect(IncidentValidator.formatSSN("123-45-6789")).toBe("123-45-6789");
    });
  });
});
