import { DynamoDBClient, GetItemCommand, QueryCommand } from "@aws-sdk/client-dynamodb";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import { RuleDefinition, RuleCondition, RuleAction } from "../../types/workflow-orchestration.types";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("RuleEngine");

const RULES_TABLE = process.env.WORKFLOW_RULES_TABLE!;

export interface RuleEvaluationResult {
  ruleId: string;
  matched: boolean;
  actions: RuleAction[];
}

export class RuleEngine {
  private readonly client = new DynamoDBClient({});

  /** Load a specific rule from the Configuration Layer (RULEDEF) */
  async loadRule(ruleId: string, version: number = 1): Promise<RuleDefinition | null> {
    logger.debug("Loading rule definition", { ruleId, version });
    const res = await this.client.send(
      new GetItemCommand({
        TableName: RULES_TABLE,
        Key: marshall({ ruleId, version }),
      })
    );
    return res.Item ? (unmarshall(res.Item) as RuleDefinition) : null;
  }

  /** Load all active rules for a domain from the Configuration Layer */
  async loadRulesForDomain(domain: string): Promise<RuleDefinition[]> {
    logger.debug("Loading rules for domain", { domain });
    const res = await this.client.send(
      new QueryCommand({
        TableName: RULES_TABLE,
        IndexName: "domain-status-index",
        KeyConditionExpression: "#domain = :domain AND #status = :status",
        ExpressionAttributeNames: { "#domain": "domain", "#status": "status" },
        ExpressionAttributeValues: marshall({ ":domain": domain, ":status": "ACTIVE" }),
      })
    );
    return (res.Items ?? []).map((i) => unmarshall(i) as RuleDefinition);
  }

  /** Evaluate a single rule definition against a context object */
  evaluate(rule: RuleDefinition, context: Record<string, any>): RuleEvaluationResult {
    logger.info("Evaluating rule", { ruleId: rule.ruleId, conditionCount: rule.conditions.length });

    const matched = rule.conditions.every((condition) => this.evaluateCondition(condition, context));

    logger.info("Rule evaluation complete", { ruleId: rule.ruleId, matched });
    return { ruleId: rule.ruleId, matched, actions: matched ? rule.actions : [] };
  }

  /** Evaluate all active rules for a domain and return matched results */
  async evaluateForDomain(domain: string, context: Record<string, any>): Promise<RuleEvaluationResult[]> {
    const rules = await this.loadRulesForDomain(domain);
    return rules.map((rule) => this.evaluate(rule, context));
  }

  private evaluateCondition(condition: RuleCondition, context: Record<string, any>): boolean {
    const actual = this.resolvePath(condition.field, context);
    const expected = condition.value;

    switch (condition.operator) {
      case "eq":      return actual === expected;
      case "neq":     return actual !== expected;
      case "gt":      return actual > expected;
      case "gte":     return actual >= expected;
      case "lt":      return actual < expected;
      case "lte":     return actual <= expected;
      case "in":      return Array.isArray(expected) && expected.includes(actual);
      case "contains":
        return typeof actual === "string" && actual.includes(String(expected));
      default:
        logger.warn("Unknown operator", { operator: condition.operator });
        return false;
    }
  }

  /** Resolve dot-notation field paths, e.g. "eventDetail.severity" */
  private resolvePath(path: string, obj: Record<string, any>): any {
    return path.split(".").reduce((acc, key) => acc?.[key], obj as any);
  }
}
