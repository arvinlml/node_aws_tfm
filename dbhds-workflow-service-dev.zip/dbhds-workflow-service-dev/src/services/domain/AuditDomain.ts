import { DatabaseAdapter } from "../../adapters/database/DynamoDBAdapter";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("AuditDomain");

const METADATA_TABLE = process.env.METADATA_TABLE!;

export class AuditDomain {
  constructor(private readonly db: DatabaseAdapter) {}

  async log(entry: {
    auditId: string;
    entityId: string;
    entityType: string;
    action: string;
    performedBy: string;
    domain: string;
    before?: Record<string, any>;
    after?: Record<string, any>;
    metadata?: Record<string, any>;
  }): Promise<void> {
    logger.info("Writing audit entry", { auditId: entry.auditId, action: entry.action });
    await this.db.put(METADATA_TABLE, {
      tableName: `audit#${entry.domain}`,
      eventType: entry.auditId,
      ...entry,
      timestamp: new Date().toISOString(),
    });
  }
}
