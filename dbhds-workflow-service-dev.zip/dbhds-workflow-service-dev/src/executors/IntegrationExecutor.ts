import { Logger } from "../utils/logger.service";
import { ApiAdapter, HttpApiAdapter } from "../adapters/api/HttpApiAdapter";

const logger = new Logger("IntegrationExecutor");

export interface IntegrationInput {
  service: string;
  endpoint: string;
  method: "GET" | "POST" | "PUT" | "DELETE";
  payload?: any;
  headers?: Record<string, string>;
}

export interface IntegrationOutput {
  success: boolean;
  statusCode?: number;
  data?: any;
  error?: string;
}

/**
 * IntegrationExecutor — Execution Layer
 *
 * Routes all external API calls through the pluggable ApiAdapter (Adapter Layer).
 * Swap HttpApiAdapter for a mock adapter in tests without changing this class.
 */
export class IntegrationExecutor {
  private readonly apiAdapter: ApiAdapter;

  constructor(apiAdapter: ApiAdapter = new HttpApiAdapter()) {
    this.apiAdapter = apiAdapter;
  }

  async execute(input: IntegrationInput): Promise<IntegrationOutput> {
    logger.info("IntegrationExecutor started", { service: input.service, method: input.method, endpoint: input.endpoint });

    try {
      const response = await this.apiAdapter.call({
        service: input.service,
        endpoint: input.endpoint,
        method: input.method,
        payload: input.payload,
        headers: input.headers,
      });

      logger.info("IntegrationExecutor completed", { statusCode: response.statusCode });
      return { success: true, statusCode: response.statusCode, data: response.data };
    } catch (error: any) {
      logger.error("IntegrationExecutor failed", { error: error.message, stack: error.stack });
      return { success: false, error: error.message };
    }
  }
}
