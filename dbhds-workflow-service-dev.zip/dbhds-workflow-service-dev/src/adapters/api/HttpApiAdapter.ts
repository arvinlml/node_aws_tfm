import { Logger } from "../../utils/logger.service";

const logger = new Logger("HttpApiAdapter");

export interface ApiRequest {
  service: string;
  endpoint: string;
  method: "GET" | "POST" | "PUT" | "DELETE";
  payload?: any;
  headers?: Record<string, string>;
}

export interface ApiResponse {
  statusCode: number;
  data: any;
}

export interface ApiAdapter {
  call(request: ApiRequest): Promise<ApiResponse>;
}

export class HttpApiAdapter implements ApiAdapter {
  private readonly serviceRegistry: Record<string, string>;

  constructor() {
    // Service base URLs resolved from environment — fully pluggable
    this.serviceRegistry = {
      "identity-provider": process.env.IDENTITY_PROVIDER_URL ?? "",
      "payroll-system": process.env.PAYROLL_SYSTEM_URL ?? "",
      "dmas-service": process.env.DMAS_SERVICE_URL ?? "",
    };
  }

  async call(request: ApiRequest): Promise<ApiResponse> {
    const baseUrl = this.serviceRegistry[request.service];
    if (!baseUrl) {
      throw new Error(`No base URL registered for service: ${request.service}`);
    }

    const url = `${baseUrl}${request.endpoint}`;
    logger.info("Calling external API", { service: request.service, method: request.method, url });

    const response = await fetch(url, {
      method: request.method,
      headers: { "Content-Type": "application/json", ...(request.headers ?? {}) },
      ...(request.payload && { body: JSON.stringify(request.payload) }),
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(`API call failed: ${response.status} ${JSON.stringify(data)}`);
    }

    logger.info("API call succeeded", { service: request.service, statusCode: response.status });
    return { statusCode: response.status, data };
  }
}
