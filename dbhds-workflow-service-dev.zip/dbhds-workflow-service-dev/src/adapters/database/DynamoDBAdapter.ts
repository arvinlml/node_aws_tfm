import {
  DynamoDBClient,
  GetItemCommand,
  PutItemCommand,
  UpdateItemCommand,
  DeleteItemCommand,
  QueryCommand,
} from "@aws-sdk/client-dynamodb";
import { marshall, unmarshall } from "@aws-sdk/util-dynamodb";
import { Logger } from "../../utils/logger.service";

const logger = new Logger("DynamoDBAdapter");

export interface DatabaseAdapter {
  get(table: string, key: Record<string, any>): Promise<any | null>;
  put(table: string, item: Record<string, any>): Promise<void>;
  update(table: string, key: Record<string, any>, updates: Record<string, any>): Promise<void>;
  delete(table: string, key: Record<string, any>): Promise<void>;
  query(table: string, keyCondition: string, values: Record<string, any>, indexName?: string): Promise<any[]>;
}

export class DynamoDBAdapter implements DatabaseAdapter {
  private readonly client = new DynamoDBClient({});

  async get(table: string, key: Record<string, any>): Promise<any | null> {
    logger.debug("get", { table, key });
    const res = await this.client.send(new GetItemCommand({ TableName: table, Key: marshall(key) }));
    return res.Item ? unmarshall(res.Item) : null;
  }

  async put(table: string, item: Record<string, any>): Promise<void> {
    logger.debug("put", { table });
    await this.client.send(
      new PutItemCommand({ TableName: table, Item: marshall(item, { removeUndefinedValues: true }) })
    );
  }

  async update(table: string, key: Record<string, any>, updates: Record<string, any>): Promise<void> {
    logger.debug("update", { table, key });
    const fields = Object.keys(updates);
    const expression = "SET " + fields.map((f) => `#${f} = :${f}`).join(", ");
    await this.client.send(
      new UpdateItemCommand({
        TableName: table,
        Key: marshall(key),
        UpdateExpression: expression,
        ExpressionAttributeNames: Object.fromEntries(fields.map((f) => [`#${f}`, f])),
        ExpressionAttributeValues: marshall(
          Object.fromEntries(fields.map((f) => [`:${f}`, updates[f]])),
          { removeUndefinedValues: true }
        ),
      })
    );
  }

  async delete(table: string, key: Record<string, any>): Promise<void> {
    logger.debug("delete", { table, key });
    await this.client.send(new DeleteItemCommand({ TableName: table, Key: marshall(key) }));
  }

  async query(
    table: string,
    keyCondition: string,
    values: Record<string, any>,
    indexName?: string
  ): Promise<any[]> {
    logger.debug("query", { table, indexName });
    const res = await this.client.send(
      new QueryCommand({
        TableName: table,
        ...(indexName && { IndexName: indexName }),
        KeyConditionExpression: keyCondition,
        ExpressionAttributeValues: marshall(values),
      })
    );
    return (res.Items ?? []).map((i) => unmarshall(i));
  }
}
