export interface WorkflowEvent {
  detailType: string;
  source: string;
  detail: {
    entityId: string;
    eventType: string;
    timestamp: string;
    data: Record<string, any>;
  };
}

export interface WorkflowDefinition {
  workflowId: string;
  workflowName: string;
  /** Domain this workflow belongs to, e.g. "incident", "employee-offboarding" */
  domain: string;
  version: string;
  triggerEvents: string[];
  steps: WorkflowStep[];
  configuration: {
    timeout: number;
    retryPolicy: {
      maxAttempts: number;
      backoffRate: number;
    };
  };
  status: string;
}

/** Rule definition stored in the workflow-rules table */
export interface RuleDefinition {
  ruleId: string;
  ruleName: string;
  domain: string;
  version: number;
  conditions: RuleCondition[];
  /** Actions to execute when ALL conditions match */
  actions: RuleAction[];
  status: "ACTIVE" | "INACTIVE";
}

export interface RuleCondition {
  field: string;
  operator: "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "in" | "contains";
  value: any;
}

export interface RuleAction {
  actionType: "SET_FIELD" | "ROUTE_TO" | "NOTIFY" | "REJECT" | "APPROVE";
  parameters: Record<string, any>;
}

export interface WorkflowStep {
  stepId: string;
  stepName: string;
  stepType: "TASK" | "CHOICE" | "PARALLEL" | "WAIT" | "PASS";
  executor?: string;
  parameters?: Record<string, any>;
  nextStep?: string;
  errorHandler?: {
    retries: number;
    fallbackStep?: string;
  };
  choices?: Array<{
    condition: string;
    nextStep: string;
  }>;
  branches?: WorkflowStep[][];
}
