import { Logger } from "../utils/logger.service";
import { NotificationService, NotificationPayload } from "../services/notification/notification.service";

const logger = new Logger("NotificationExecutor");

export interface NotificationInput {
  type: "email" | "sms" | "push" | "webhook";
  recipients: string[];
  subject?: string;
  message: string;
  userId?: string;
  serviceName?: string;
  from?: string;
  cc?: string;
  metadata?: any;
}

export interface NotificationOutput {
  success: boolean;
  sent: boolean;
  messageId?: string;
  error?: string;
}

export class NotificationExecutor {
  private notificationService: NotificationService;

  constructor() {
    this.notificationService = new NotificationService();
  }

  async execute(input: NotificationInput): Promise<NotificationOutput> {
    logger.info("NotificationExecutor started", {
      type: input.type,
      recipientsCount: input.recipients.length,
    });

    try {
      if (input.type === "email") {
        return await this.sendEmail(input);
      }

      logger.warn("Notification type not implemented", { type: input.type });
      return {
        success: false,
        sent: false,
        error: `Notification type '${input.type}' not implemented`,
      };
    } catch (error: any) {
      logger.error("NotificationExecutor failed", { error: error.message, stack: error.stack });
      return {
        success: false,
        sent: false,
        error: error.message,
      };
    }
  }

  private async sendEmail(input: NotificationInput): Promise<NotificationOutput> {
    const payload: NotificationPayload = {
      userId: input.userId || "system#workflow#notification",
      recipientEmail: {
        to: input.recipients[0],
        from: input.from || "noreply@yourdomain.com",
        ...(input.cc && { cc: input.cc }),
      },
      serviceName: input.serviceName || "DAP",
      channel: "email",
      subject: input.subject || "Notification",
      body: input.message,
    };

    const result = await this.notificationService.sendEmail(payload);

    if (result.success) {
      logger.info("NotificationExecutor completed", { messageId: result.messageId });
      return {
        success: true,
        sent: true,
        messageId: result.messageId,
      };
    }

    return {
      success: false,
      sent: false,
      error: result.error,
    };
  }
}
