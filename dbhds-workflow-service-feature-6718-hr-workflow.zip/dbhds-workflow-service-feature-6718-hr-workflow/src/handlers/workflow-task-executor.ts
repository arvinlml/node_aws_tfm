import { Context } from "aws-lambda";

export const handler = async (event: any, context: Context) => {
  console.log("Task executor invoked", {
    requestId: context.awsRequestId,
    event: JSON.stringify(event),
  });

  const { stepId, stepName, parameters } = event;

  console.log(`Executing step: ${stepName} (${stepId})`);
  console.log(`Parameters:`, parameters);

  // Simulate task execution based on action
  const action = parameters?.action;

  switch (action) {
    case "validate":
      console.log("Validating incident...");
      return {
        success: true,
        action: "validate",
        result: "Incident validated successfully",
        timestamp: new Date().toISOString(),
      };

    case "notify":
      console.log(`Sending notification via ${parameters.channel}...`);
      return {
        success: true,
        action: "notify",
        channel: parameters.channel,
        result: "Notification sent successfully",
        timestamp: new Date().toISOString(),
      };

    default:
      console.log("Executing generic task...");
      return {
        success: true,
        action: action || "unknown",
        result: "Task completed",
        timestamp: new Date().toISOString(),
      };
  }
};
