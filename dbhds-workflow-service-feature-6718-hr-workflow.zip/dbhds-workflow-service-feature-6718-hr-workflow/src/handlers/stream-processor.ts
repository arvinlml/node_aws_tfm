import { DynamoDBRecord, Context } from "aws-lambda";
import { EventBridgeClient, PutEventsCommand } from "@aws-sdk/client-eventbridge";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";
import { AttributeValue } from "@aws-sdk/client-dynamodb";
import { TableMetadata } from "../types/event-pipeline.types";

const eventBridgeClient = new EventBridgeClient({});
const dynamoClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamoClient);

const EVENT_BUS_NAME = process.env.EVENT_BUS_NAME!;
const METADATA_TABLE = process.env.EVENT_METADATA_TABLE!;

export const handler = async (event: any, context: Context): Promise<any> => {
  console.log("Event enrichment handler invoked", {
    requestId: context.awsRequestId,
    event: JSON.stringify(event),
    MetadataTableName: METADATA_TABLE,
  });

  // Handle EventBridge Pipes format
  const records = event.Records || (Array.isArray(event) ? event : [event]);

  const batchItemFailures: { itemIdentifier: string }[] = [];

  for (const record of records) {
    try {
      await processRecord(record);
    } catch (error: any) {
      console.error("Failed to process record", {
        sequenceNumber: record.dynamodb?.SequenceNumber,
        error: error.message,
        stack: error.stack,
      });

      // Report failed item for retry
      if (record.dynamodb?.SequenceNumber) {
        batchItemFailures.push({
          itemIdentifier: record.dynamodb.SequenceNumber,
        });
      }
    }
  }

  // Return batch item failures for partial batch response
  return {
    batchItemFailures,
  };
};

async function processRecord(record: DynamoDBRecord): Promise<void> {
  const eventName = record.eventName; // INSERT, MODIFY, REMOVE
  const tableName = record.eventSourceARN?.split("/")[1]; // Extract table name from ARN

  if (!eventName || !tableName) {
    console.warn("Missing eventName or tableName", { record });
    return;
  }

  console.log("Processing DynamoDB Stream record", {
    eventName,
    tableName,
    sequenceNumber: record.dynamodb?.SequenceNumber,
  });

  // Get metadata configuration for this table
  const metadata = await getTableMetadata(tableName);
  if (!metadata) {
    console.log("No metadata configuration found for table", { tableName });
    return;
  }

  // Get event mapping for this operation type
  if (!metadata.eventMappings) {
    console.log("No event mapping for operation", { tableName, eventName });
    return;
  }

  // Get event mapping for this operation type
  const eventMapping = metadata.eventMappings[eventName as keyof typeof metadata.eventMappings];
  // Validate event mapping has all required fields
  if (!eventMapping) {
    console.log("Invalid or missing event mapping for operation", { tableName, eventName });
    return;
  }

  // Extract the new image (for INSERT/MODIFY) or old image (for REMOVE)
  let itemData: any;
  if (eventName === "REMOVE" && record.dynamodb?.OldImage) {
    itemData = unmarshall(record.dynamodb.OldImage as Record<string, AttributeValue>);
  } else if (record.dynamodb?.NewImage) {
    itemData = unmarshall(record.dynamodb.NewImage as Record<string, AttributeValue>);
  } else {
    console.warn("No image data available", { eventName });
    return;
  }

  // Filter fields if specified
  let eventDetail = itemData;
  if (eventMapping.includeFields && eventMapping.includeFields.length > 0) {
    eventDetail = {};
    for (const field of eventMapping.includeFields) {
      if (itemData[field] !== undefined) {
        eventDetail[field] = itemData[field];
      }
    }
  }

  // Add metadata
  eventDetail.metadata = {
    tableName,
    operation: eventName,
    timestamp: new Date().toISOString(),
    streamSequenceNumber: record.dynamodb?.SequenceNumber,
  };

  // Publish to EventBridge
  await publishToEventBridge({
    source: eventMapping.source,
    detailType: eventMapping.detailType,
    detail: eventDetail,
    eventType: eventMapping.eventType,
    eventVersion: "1.0",
  });

  console.log("Event published successfully", {
    eventType: eventMapping.eventType,
    tableName,
    operation: eventName,
  });
}

async function getTableMetadata(tableName: string): Promise<TableMetadata | null> {
  try {
    console.log("Fetching meta information from ", METADATA_TABLE);
    const response = await docClient.send(
      new GetCommand({
        TableName: METADATA_TABLE,
        Key: {
          tableName,
          eventType: "incident",
        },
      }),
    );
    console.log("Response item ", response?.Item);
    return response.Item as TableMetadata | null;
  } catch (error: any) {
    console.error("Failed to get table metadata", {
      tableName,
      error: error.message,
    });
    return null;
  }
}

async function publishToEventBridge(params: {
  source: string;
  detailType: string;
  detail: any;
  eventType: string;
  eventVersion: string;
}): Promise<void> {
  const { source, detailType, detail, eventType, eventVersion } = params;
  console.log("all the params ", params);
  console.log("Event bus name ", EVENT_BUS_NAME);
  const command = new PutEventsCommand({
    Entries: [
      {
        Source: source,
        DetailType: detailType,
        Detail: JSON.stringify({
          ...detail,
          eventType,
          eventVersion,
        }),
        EventBusName: EVENT_BUS_NAME,
        Time: new Date(),
      },
    ],
  });

  const response = await eventBridgeClient.send(command);

  if (response.FailedEntryCount && response.FailedEntryCount > 0) {
    console.error("Failed to publish event to EventBridge", {
      failures: response.Entries,
    });
    throw new Error(`Failed to publish ${response.FailedEntryCount} events`);
  }

  console.log("Event published to EventBridge", {
    source,
    detailType,
    eventType,
  });
}
