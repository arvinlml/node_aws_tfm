import { Context } from "aws-lambda";
import {
  SFNClient,
  StartExecutionCommand,
  CreateStateMachineCommand,
  DescribeStateMachineCommand,
  UpdateStateMachineCommand,
} from "@aws-sdk/client-sfn";
import { v4 as uuidv4 } from "uuid";
import { WorkflowDefinition, WorkflowStep } from "../types/workflow-orchestration.types";
import { findWorkflowByEvent } from "../services/workflow-orchestration/workflow-finder.service";

const sfnClient = new SFNClient({});

const WORKFLOW_METADATA_TABLE = process.env.WORKFLOW_METADATA_TABLE!;
const STATE_MACHINE_ROLE_ARN = process.env.STATE_MACHINE_ROLE_ARN!;

/**
 * GENERIC WORKFLOW ORCHESTRATOR
 * Works for ANY workflow - just change the workflow metadata!
 */
export const handler = async (event: any, context: Context) => {
  console.log("Workflow orchestrator invoked", {
    requestId: context.awsRequestId,
    eventType: event["detail-type"],
  });

  try {
    const detailType = event["detail-type"];
    const { detail } = event;

    // Find workflow by event type (no hardcoding!)
    const workflowDefinition = await findWorkflowByEvent(detailType, WORKFLOW_METADATA_TABLE);

    if (!workflowDefinition) {
      console.log(`No workflow configured for event: ${detailType}`);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "No matching workflow found" }),
      };
    }

    console.log(`Executing workflow: ${workflowDefinition.workflowName}`);

    // Generate state machine from metadata
    const stateMachineDefinition = generateStateMachineDefinition(workflowDefinition);

    // Create or update state machine
    const stateMachineArn = await ensureStateMachine(
      workflowDefinition.workflowId,
      workflowDefinition.workflowName,
      stateMachineDefinition,
    );

    // Start execution
    const executionArn = await startWorkflowExecution(stateMachineArn, workflowDefinition, detail);

    console.log(`Workflow execution started: ${executionArn}`);

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Workflow orchestration initiated",
        executionArn,
        workflowId: workflowDefinition.workflowId,
      }),
    };
  } catch (error) {
    console.error("Error orchestrating workflow:", error);
    throw error;
  }
};

function generateStateMachineDefinition(workflow: WorkflowDefinition): string {
  const states: Record<string, any> = {};

  workflow.steps.forEach((step, index) => {
    const isLastStep = index === workflow.steps.length - 1;

    switch (step.stepType) {
      case "TASK":
        states[step.stepName] = {
          Type: "Task",
          Resource: "arn:aws:states:::lambda:invoke",
          Parameters: {
            FunctionName: `${step.executor}:$LATEST`,
            Payload: {
              "executionId.$": "$$.Execution.Name",
              stepId: step.stepId,
              stepName: step.stepName,
              parameters: step.parameters || {},
              "input.$": "$",
            },
          },
          ResultPath: `$.result_${step.stepId.replace(/-/g, "_")}`,
          ResultSelector: {
            "output.$": "$.Payload",
          },
          Retry: [
            {
              ErrorEquals: ["States.TaskFailed", "States.Timeout"],
              IntervalSeconds: 2,
              MaxAttempts: step.errorHandler?.retries || workflow.configuration.retryPolicy.maxAttempts,
              BackoffRate: workflow.configuration.retryPolicy.backoffRate,
            },
          ],
          Catch: step.errorHandler?.fallbackStep
            ? [
                {
                  ErrorEquals: ["States.ALL"],
                  Next: step.errorHandler.fallbackStep,
                  ResultPath: "$.error",
                },
              ]
            : undefined,
          Next: isLastStep ? "Success" : step.nextStep || workflow.steps[index + 1].stepName,
          TimeoutSeconds: 300,
        };
        break;

      case "CHOICE":
        states[step.stepName] = {
          Type: "Choice",
          Choices:
            step.choices?.map((choice) => {
              const conditionParts = choice.condition.split(" ");
              return {
                Variable: conditionParts[0],
                StringEquals: conditionParts[2]?.replace(/['"]/g, ""),
                Next: choice.nextStep,
              };
            }) || [],
          Default: step.nextStep || "Success",
        };
        break;

      case "PARALLEL":
        states[step.stepName] = {
          Type: "Parallel",
          Branches:
            step.branches?.map((branch) => ({
              StartAt: branch[0].stepName,
              States: generateBranchStates(branch),
            })) || [],
          Next: isLastStep ? "Success" : step.nextStep || workflow.steps[index + 1].stepName,
          ResultPath: `$.result_${step.stepId.replace(/-/g, "_")}`,
        };
        break;

      case "WAIT":
        states[step.stepName] = {
          Type: "Wait",
          Seconds: step.parameters?.seconds || 60,
          Next: isLastStep ? "Success" : step.nextStep || workflow.steps[index + 1].stepName,
        };
        break;

      case "PASS":
        states[step.stepName] = {
          Type: "Pass",
          Result: step.parameters || {},
          ResultPath: `$.steps.${step.stepName}`,
          Next: isLastStep ? "Success" : step.nextStep || workflow.steps[index + 1].stepName,
        };
        break;
    }
  });

  states["Success"] = {
    Type: "Succeed",
  };

  const stateMachine = {
    Comment: `Generated state machine for ${workflow.workflowName}`,
    StartAt: workflow.steps[0].stepName,
    States: states,
    TimeoutSeconds: workflow.configuration.timeout,
  };

  return JSON.stringify(stateMachine, null, 2);
}

function generateBranchStates(steps: WorkflowStep[]): Record<string, any> {
  const states: Record<string, any> = {};

  steps.forEach((step, index) => {
    const isLastStep = index === steps.length - 1;
    states[step.stepName] = {
      Type: "Task",
      Resource: "arn:aws:states:::lambda:invoke",
      Parameters: {
        FunctionName: `${step.executor}:$LATEST`,
        Payload: {
          stepId: step.stepId,
          parameters: step.parameters || {},
          "input.$": "$",
        },
      },
      End: isLastStep,
      Next: isLastStep ? undefined : steps[index + 1].stepName,
    };
  });

  return states;
}

async function ensureStateMachine(workflowId: string, workflowName: string, definition: string): Promise<string> {
  const stateMachineName = `workflow-${workflowId}`;
  const region = process.env.AWS_REGION || "us-east-1";
  const accountId = process.env.ACCOUNT_ID!;

  try {
    const describeResponse = await sfnClient.send(
      new DescribeStateMachineCommand({
        stateMachineArn: `arn:aws:states:${region}:${accountId}:stateMachine:${stateMachineName}`,
      }),
    );

    await sfnClient.send(
      new UpdateStateMachineCommand({
        stateMachineArn: describeResponse.stateMachineArn,
        definition,
        roleArn: STATE_MACHINE_ROLE_ARN,
      }),
    );

    console.log(`Updated state machine: ${stateMachineName}`);
    return describeResponse.stateMachineArn!;
  } catch (error: any) {
    if (error.name === "StateMachineDoesNotExist") {
      const createResponse = await sfnClient.send(
        new CreateStateMachineCommand({
          name: stateMachineName,
          definition,
          roleArn: STATE_MACHINE_ROLE_ARN,
          type: "STANDARD",
          tags: [
            { key: "WorkflowId", value: workflowId },
            { key: "WorkflowName", value: workflowName },
          ],
        }),
      );

      console.log(`Created state machine: ${stateMachineName}`);
      return createResponse.stateMachineArn!;
    }
    throw error;
  }
}

async function startWorkflowExecution(
  stateMachineArn: string,
  workflow: WorkflowDefinition,
  eventDetail: any,
): Promise<string> {
  const uuid = uuidv4();
  const maxWorkflowIdLength = 80 - 5 - 36 - 1; // 80 total - 'exec-' - uuid - '-'
  const truncatedWorkflowId = workflow.workflowId.substring(0, maxWorkflowIdLength);
  const executionName = `exec-${truncatedWorkflowId}-${uuid}`;

  const response = await sfnClient.send(
    new StartExecutionCommand({
      stateMachineArn,
      name: executionName,
      input: JSON.stringify({
        workflowId: workflow.workflowId,
        workflowName: workflow.workflowName,
        eventDetail,
        startTime: new Date().toISOString(),
      }),
    }),
  );

  return response.executionArn!;
}
