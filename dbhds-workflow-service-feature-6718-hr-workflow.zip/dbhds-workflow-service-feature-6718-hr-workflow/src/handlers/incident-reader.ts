import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
import { randomUUID } from "crypto";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand, ScanCommand } from "@aws-sdk/lib-dynamodb";

// Initialize DynamoDB client
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGINS || "*",
  "Access-Control-Allow-Headers":
    "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Correlation-ID",
  "Access-Control-Allow-Methods": "OPTIONS,GET",
  "Content-Type": "application/json",
};

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  console.log("GetIncident handler invoked", {
    path: event.path,
    method: event.httpMethod,
    pathParameters: event.pathParameters,
    queryStringParameters: event.queryStringParameters,
  });

  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  const correlationId = event.headers["X-Correlation-ID"] || event.headers["x-correlation-id"] || randomUUID();

  try {
    // Get single incident by incidentId (requires Scan since it's not a key)
    if (event.pathParameters?.incidentId) {
      const incidentId = event.pathParameters.incidentId;

      console.log("Scanning for incident by ID", {
        incidentId,
        tableName: process.env.INCIDENTS_TABLE,
      });

      const result = await docClient.send(
        new ScanCommand({
          TableName: process.env.INCIDENTS_TABLE!,
          FilterExpression: "incidentId = :incidentId",
          ExpressionAttributeValues: {
            ":incidentId": incidentId,
          },
          Limit: 1, // Stop after finding the first match
        })
      );

      console.log("Scan result", {
        itemCount: result.Items?.length || 0,
        incidentId,
      });

      if (!result.Items || result.Items.length === 0) {
        return {
          statusCode: 404,
          headers: CORS_HEADERS,
          body: JSON.stringify({
            success: false,
            error: {
              message: "Incident not found",
              incidentId,
              correlationId,
            },
          }),
        };
      }

      const incident = result.Items[0];

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          data: incident,
          metadata: {
            correlationId,
            timestamp: new Date().toISOString(),
          },
        }),
      };
    }

    // Get incident by email and lastName (primary key) - Direct query
    if (event.queryStringParameters?.incidentId && event.queryStringParameters?.lastName) {
      const incidentId = event.queryStringParameters.incidentId;

      console.log("Querying incident by IncidentId", {
        incidentId,
        tableName: process.env.INCIDENTS_TABLE,
      });

      const result = await docClient.send(
        new QueryCommand({
          TableName: process.env.INCIDENTS_TABLE!,
          KeyConditionExpression: "incidentId = :incidentId",
          ExpressionAttributeValues: {
            ":incidentId": incidentId,
          },
        })
      );

      if (!result.Items || result.Items.length === 0) {
        return {
          statusCode: 404,
          headers: CORS_HEADERS,
          body: JSON.stringify({
            success: false,
            error: {
              message: "Incident not found",
              incidentId,
              correlationId,
            },
          }),
        };
      }

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          data: result.Items,
          metadata: {
            count: result.Items.length,
            correlationId,
            timestamp: new Date().toISOString(),
          },
        }),
      };
    }

    // Get all incidents for a specific email
    if (event.queryStringParameters?.email) {
      const email = event.queryStringParameters.email;

      console.log("Querying all incidents for email", {
        email,
        tableName: process.env.INCIDENTS_TABLE,
      });

      const result = await docClient.send(
        new QueryCommand({
          TableName: process.env.INCIDENTS_TABLE!,
          KeyConditionExpression: "email = :email",
          ExpressionAttributeValues: {
            ":email": email,
          },
        })
      );

      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          data: result.Items || [],
          metadata: {
            count: result.Items?.length || 0,
            email,
            correlationId,
            timestamp: new Date().toISOString(),
          },
        }),
      };
    }

    // List incidents with filters (Scan operation)
    console.log("Scanning incidents with filters", {
      queryStringParameters: event.queryStringParameters,
    });

    const filterExpressions: string[] = [];
    const expressionAttributeValues: Record<string, any> = {};
    const expressionAttributeNames: Record<string, string> = {};

    if (event.queryStringParameters?.status) {
      filterExpressions.push("#status = :status");
      expressionAttributeValues[":status"] = event.queryStringParameters.status;
      expressionAttributeNames["#status"] = "status";
    }

    if (event.queryStringParameters?.severity) {
      filterExpressions.push("severity = :severity");
      expressionAttributeValues[":severity"] = event.queryStringParameters.severity;
    }

    if (event.queryStringParameters?.incidentType) {
      filterExpressions.push("incidentType = :incidentType");
      expressionAttributeValues[":incidentType"] = event.queryStringParameters.incidentType;
    }

    if (event.queryStringParameters?.incidentId) {
      filterExpressions.push("incidentId = :incidentId");
      expressionAttributeValues[":incidentId"] = event.queryStringParameters.incidentId;
    }

    const scanParams: any = {
      TableName: process.env.INCIDENTS_TABLE!,
      Limit: parseInt(event.queryStringParameters?.limit || "50"),
    };

    if (filterExpressions.length > 0) {
      scanParams.FilterExpression = filterExpressions.join(" AND ");
      scanParams.ExpressionAttributeValues = expressionAttributeValues;
      if (Object.keys(expressionAttributeNames).length > 0) {
        scanParams.ExpressionAttributeNames = expressionAttributeNames;
      }
    }

    if (event.queryStringParameters?.lastEvaluatedKey) {
      try {
        scanParams.ExclusiveStartKey = JSON.parse(
          Buffer.from(event.queryStringParameters.lastEvaluatedKey, "base64").toString()
        );
      } catch (error) {
        console.warn("Invalid lastEvaluatedKey provided", error);
      }
    }

    const result = await docClient.send(new ScanCommand(scanParams));

    const response: any = {
      success: true,
      data: result.Items || [],
      metadata: {
        count: result.Items?.length || 0,
        scannedCount: result.ScannedCount || 0,
        filters: event.queryStringParameters || {},
        correlationId,
        timestamp: new Date().toISOString(),
      },
    };

    // Add pagination token if there are more results
    if (result.LastEvaluatedKey) {
      response.metadata.lastEvaluatedKey = Buffer.from(JSON.stringify(result.LastEvaluatedKey)).toString("base64");
      response.metadata.hasMore = true;
    }

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify(response),
    };
  } catch (error: any) {
    console.error("Error in GetIncident handler:", {
      error: error.message,
      stack: error.stack,
      errorName: error.name,
      correlationId,
    });

    if (error.name === "ResourceNotFoundException") {
      return {
        statusCode: 500,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: false,
          error: {
            message: "DynamoDB table not found",
            details: error.message,
            correlationId,
          },
        }),
      };
    }

    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: false,
        error: {
          message: "Internal server error",
          details: error.message,
          correlationId,
        },
      }),
    };
  }
};
