import { APIGatewayProxyResult } from "aws-lambda";
import { AppError } from "./errorHandler";

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  metadata?: {
    timestamp: string;
    requestId?: string;
  };
}

export const createSuccessResponse = <T>(
  data: T,
  statusCode: number = 200,
  requestId?: string,
): APIGatewayProxyResult => {
  const response: ApiResponse<T> = {
    success: true,
    data,
    metadata: {
      timestamp: new Date().toISOString(),
      requestId,
    },
  };

  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true,
    },
    body: JSON.stringify(response),
  };
};

export const createErrorResponse = (
  error: Error | AppError,
  requestId?: string,
): APIGatewayProxyResult => {
  const isAppError = error instanceof AppError;

  const statusCode = isAppError ? error.statusCode : 500;
  const errorCode = isAppError ? error.code : "INTERNAL_SERVER_ERROR";
  const errorMessage = error.message || "An unexpected error occurred";
  const errorDetails = isAppError ? error.details : undefined;

  const response: ApiResponse = {
    success: false,
    error: {
      code: errorCode,
      message: errorMessage,
      details: errorDetails,
    },
    metadata: {
      timestamp: new Date().toISOString(),
      requestId,
    },
  };

  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Credentials": true,
    },
    body: JSON.stringify(response),
  };
};
