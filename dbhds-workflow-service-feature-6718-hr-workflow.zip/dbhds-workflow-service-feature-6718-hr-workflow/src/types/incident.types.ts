/**
 * Incident domain type definitions
 */

export enum Gender {
  MALE = "MALE",
  FEMALE = "FEMALE",
  NON_BINARY = "NON_BINARY",
  PREFER_NOT_TO_SAY = "PREFER_NOT_TO_SAY",
  OTHER = "OTHER",
}

export enum IncidentType {
  MEDICAL = "MEDICAL",
  SAFETY = "SAFETY",
  SECURITY = "SECURITY",
  ENVIRONMENTAL = "ENVIRONMENTAL",
  PROPERTY_DAMAGE = "PROPERTY_DAMAGE",
  WORKPLACE_INJURY = "WORKPLACE_INJURY",
  VEHICLE_ACCIDENT = "VEHICLE_ACCIDENT",
  FIRE = "FIRE",
  THEFT = "THEFT",
  HARASSMENT = "HARASSMENT",
  DATA_BREACH = "DATA_BREACH",
  EQUIPMENT_FAILURE = "EQUIPMENT_FAILURE",
  OTHER = "OTHER",
}

export enum IncidentSeverity {
  CRITICAL = "CRITICAL",
  HIGH = "HIGH",
  MEDIUM = "MEDIUM",
  LOW = "LOW",
  INFORMATIONAL = "INFORMATIONAL",
}

export enum IncidentStatus {
  DRAFT = "DRAFT",
  SUBMITTED = "SUBMITTED",
  UNDER_REVIEW = "UNDER_REVIEW",
  INVESTIGATING = "INVESTIGATING",
  PENDING_APPROVAL = "PENDING_APPROVAL",
  APPROVED = "APPROVED",
  REJECTED = "REJECTED",
  RESOLVED = "RESOLVED",
  CLOSED = "CLOSED",
  REOPENED = "REOPENED",
}

export interface CommunicationAddress {
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  addressType?: "HOME" | "WORK" | "MAILING" | "OTHER";
}

export interface Incident {
  incidentId: string;
  firstName: string;
  lastName: string;
  gender: Gender;
  dateOfBirth: string;
  contactNumber: string;
  email: string;
  communicationAddress: string;
  incidentType: string;
  severity: IncidentSeverity;
  ssn: string;
  status: IncidentStatus;
  priority: string;
  title: string;
  description: string;
  reportedBy: string;
  reportedAt: string;
  createdAt: string;
  updatedAt: string;
  location?: string;
  category?: string;
  affectedPersons?: any[];
  metadata?: any;
  tenantId?: string;
  coverageType?: string;
}

// RDS PostgreSQL table structure (for reference)
export interface IncidentRDS {
  incident_id: string;
  first_name: string;
  last_name: string;
  gender: Gender;
  date_of_birth: Date;
  contact_number: string;
  email_address: string;
  ssn_hash?: string;
  address_line1: string;
  address_line2?: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
  incident_type: IncidentType;
  severity: IncidentSeverity;
  status: IncidentStatus;
  description?: string;
  incident_date?: Date;
  incident_location?: string;
  workflow_execution_id?: string;
  reported_by: string;
  reported_at: Date;
  created_at: Date;
  updated_at: Date;
  created_by: string;
  updated_by: string;
  version: number;
  is_deleted: boolean;
}
