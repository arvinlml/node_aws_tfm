import { Logger } from "../../utils/logger.service";

const logger = new Logger("NotificationService");

export interface EmailRecipient {
  to: string;
  from: string;
  cc?: string;
}

export interface NotificationPayload {
  userId: string;
  recipientEmail: EmailRecipient;
  serviceName: string;
  channel: "email" | "sms";
  subject: string;
  body?: string;
}

export interface NotificationResponse {
  success: boolean;
  messageId?: string;
  error?: string;
}

export class NotificationService {
  private readonly apiEndpoint: string;

  constructor(apiEndpoint?: string) {
    this.apiEndpoint =
      apiEndpoint ||
      process.env.NOTIFICATION_API_ENDPOINT ||
      "https://nckvixvu0b.execute-api.us-east-1.amazonaws.com/dev/notifications/send";
  }

  async sendEmail(payload: NotificationPayload): Promise<NotificationResponse> {
    logger.info("Sending email notification", {
      payload: JSON.stringify(payload),
    });

    try {
      const response = await fetch(this.apiEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Notification API error: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      logger.info("Email notification sent successfully", { result });

      return {
        success: true,
        messageId: result.messageId || result.id,
      };
    } catch (error: any) {
      logger.error("Failed to send email notification", {
        error: error.message,
        stack: error.stack,
      });

      return {
        success: false,
        error: error.message,
      };
    }
  }
}
