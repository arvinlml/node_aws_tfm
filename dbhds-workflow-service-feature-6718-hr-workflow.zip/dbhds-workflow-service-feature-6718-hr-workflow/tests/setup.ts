// Mock environment variables for testing
process.env.AWS_REGION = 'us-east-1';
process.env.DYNAMODB_TABLE_NAME = 'test-incident-workflow-table';
process.env.EVENT_BUS_NAME = 'test-incident-workflow-bus';
process.env.ENVIRONMENT = 'test';
process.env.LOG_LEVEL = 'error';
process.env.SSN_SALT = 'test-salt-for-testing-only';
