import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { readFile } from "node:fs/promises";
import { createReadStream } from "node:fs";
import { config } from "dotenv";
import { execSync } from "node:child_process";

// Load .env.dev file
config({ path: ".env.dev" });

const bucket = process.env.ARTIFACT_BUCKET;
if (!bucket) throw new Error("ARTIFACT_BUCKET is required");

const stage = process.env.ENVIRONMENT ?? "dev";
const service = process.env.SERVICE_NAME ?? "dbhds-workflow-service";
const version = process.env.GIT_SHA || execSync("git rev-parse HEAD").toString().trim();

const region = process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || "us-east-1";
const s3 = new S3Client({ region });

const manifest = JSON.parse(await readFile("dist/manifest.json", "utf8"));

function utcStamp() {
  // 20260226T153045Z
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return d.getUTCFullYear() + pad(d.getUTCMonth() + 1) + pad(d.getUTCDate());
}

const stamp = utcStamp();
const fileTag = `${version}-${stamp}`; // used in filenames

async function uploadZip(localPath, key) {
  await s3.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: createReadStream(localPath),
      ContentType: "application/zip",
    }),
  );
  return `s3://${bucket}/${key}`;
}

const uploads = {
  stage,
  service,
  version,
  stamp,
  region,
  bucket,
  handlers: [],
  layer: null,
  manifestKey: null,
};

// Upload layer zip with version+timestamp in filename
{
  const key = `${service}/${stage}/layers/${manifest.layer.name}/${fileTag}.zip`;
  await uploadZip(manifest.layer.zipPath, key);
  uploads.layer = { name: manifest.layer.name, s3_key: key, sha256: manifest.layer.sha256 };
}

// Upload handler zips with version+timestamp in filename
for (const h of manifest.handlers) {
  const key = `${service}/${stage}/handlers/${h.name}/${h.name}-${fileTag}.zip`;
  await uploadZip(h.zipPath, key);
  uploads.handlers.push({ name: h.name, s3_key: key, sha256: h.sha256 });
}

// Upload publish manifest (also version+timestamp)
const publishManifestKey = `${service}/${stage}/manifests/${fileTag}.json`;
await s3.send(
  new PutObjectCommand({
    Bucket: bucket,
    Key: publishManifestKey,
    Body: JSON.stringify(uploads, null, 2),
    ContentType: "application/json",
  }),
);

console.log(JSON.stringify({ uploaded: uploads, manifest: `s3://${bucket}/${publishManifestKey}` }, null, 2));
